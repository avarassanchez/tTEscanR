test_that("Checking the codon pool contribution", {

  data(metadata)

  tTEscanR_obj <- Create_tTEscanR_Object(counts = mRNA_data_test, assay = "mRNA")
  expect_error(ShowPoolContribution(object = tTEscanR_obj, species = "hg38", verbose = FALSE)) # codon usage not present in object

  tTEscanR_obj <- ComputeCodonUsage(object = tTEscanR_obj, species = "hg38", additional_metrics = FALSE)
  expect_error(ShowPoolContribution(object = tTEscanR_obj, species = "hg38", verbose = FALSE)) # metadata and corr_factor not present in object

  tTEscanR_obj <- Update_tTEscanR_Object(object = tTEscanR_obj, meta.data = list(metadata, "tissue"), meta.data.ids = list("ConditionsLabels", "CorrectionFactor"))
  expect_no_error(ShowPoolContribution(object = tTEscanR_obj, species = "hg38", verbose = FALSE))
})

test_that("Input validation for ShowPoolContribution catches bad arguments", {

  data(metadata)

  # CASE 1: wrong corr_factor
  tTEscanR_obj <- Create_tTEscanR_Object(counts = mRNA_data_test, assay = "mRNA")
  tTEscanR_obj <- ComputeCodonUsage(object = tTEscanR_obj, species = "hg38", additional_metrics = FALSE)
  tTEscanR_obj <- Update_tTEscanR_Object(object = tTEscanR_obj, meta.data = list(metadata, "FakeColumn"), meta.data.ids = list("ConditionsLabels", "CorrectionFactor"))
  expect_error(ShowPoolContribution(object = tTEscanR_obj, species = "hg38", verbose = FALSE), "The correction factor was not found in the metadata")

  # CASE 2: no-intersecting genes
  tTEscanR_obj <- Update_tTEscanR_Object(object = tTEscanR_obj, meta.data = list(metadata, "tissue"), meta.data.ids = list("ConditionsLabels", "CorrectionFactor"), overwrite_assay = TRUE, overwrite_metadata = TRUE)
  fake_genes <- c("FakeGene1", "FakeGene2")
  fake_codons <- apply(expand.grid(c("A","C","G","T"), c("A","C","G","T"), c("A","C","G","T")), 1, paste, collapse="")
  bad_codon_freq <- matrix(1, nrow = 64, ncol = 2, dimnames = list(fake_codons, fake_genes))
  expect_error(ShowPoolContribution(object = tTEscanR_obj, codon_freq = bad_codon_freq, verbose = FALSE), "No mRNAs in common found")
})

test_that("ShowPoolContribution correctly updates the tTEscanR object slots", {

  tTEscanR_obj <- Create_tTEscanR_Object(counts = mRNA_data_test, assay = "mRNA")
  tTEscanR_obj <- ComputeCodonUsage(object = tTEscanR_obj, species = "hg38", additional_metrics = FALSE)
  tTEscanR_obj <- Update_tTEscanR_Object(object = tTEscanR_obj, meta.data = list(metadata, "tissue"), meta.data.ids = list("ConditionsLabels", "CorrectionFactor"))

  tTEscanR_obj <- ShowPoolContribution(object = tTEscanR_obj, species = "hg38", N = 10, verbose = FALSE)

  expect_true("SizeCorrectedCodonUsage" %in% names(tTEscanR_obj@assays))
  expect_true("SizeCorrected_mRNA" %in% names(tTEscanR_obj@assays))

  expect_true("CodonPoolContribution_Results" %in% names(tTEscanR_obj@meta.data))

  meta_results <- tTEscanR_obj@meta.data$CodonPoolContribution_Results
  expect_true("CodonPoolContribution" %in% names(meta_results))
  expect_true("PoolContributorTop10Genes" %in% names(meta_results))
  expect_true("CorrelationTop10Genes" %in% names(meta_results))

  # Run it again with a different N to ensure the dynamic naming works
  tTEscanR_obj <- ShowPoolContribution(object = tTEscanR_obj, species = "hg38", N = 5, verbose = FALSE, overwrite_assay = TRUE, overwrite_metadata = TRUE)
  expect_true("PoolContributorTop5Genes" %in% names(tTEscanR_obj@meta.data$CodonPoolContribution_Results))
})
