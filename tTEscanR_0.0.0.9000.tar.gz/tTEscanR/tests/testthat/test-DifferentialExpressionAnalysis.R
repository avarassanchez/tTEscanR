test_that("The differential expression analysis is correctly executed", {
  data(mRNA_data)
  mRNA_data_subset <- mRNA_data[0:1000, 0:100]
  expect_no_error(DESeq2runner(data = mRNA_data_subset, conditions = c("tissue", "cell.type"),
                               name_sep = "-", formula = ~ tissue, heatmap = TRUE, PCA = TRUE,
                               numPC = 5, color_factor = "tissue", labels = FALSE))
  expect_no_error(DESeq2runner(data = mRNA_data_subset, conditions = c("tissue", "cell.type"),
                               name_sep = "-", formula = ~ tissue, heatmap = TRUE, PCA = TRUE,
                               numPC = 5, color_factor = "tissue", labels = TRUE))

  expect_error(DESeq2runner(data = mRNA_data_subset, conditions = c("tissue", "cell.type"),
                            name_sep = "-", formula = ~ tissue)) # color_factor missing
  expect_error(DESeq2runner(data = mRNA_data_subset, conditions = c("tissue", "cell.type"),
                            name_sep = "-", numPC = 2, color_factor = "tissue", labels = FALSE)) # formula missing
  expect_error(DESeq2runner(data = mRNA_data_subset, name_sep = "-", formula = ~ tissue,
                            heatmap = TRUE, PCA = TRUE, numPC = 5, color_factor = "tissue", labels = FALSE)) # conditions missing

})

# targets_endothelial <- data.frame(search = c("endothelial"), class = c("endothelial"))

#expect_no_error(DESeq2runner(data = mRNA_data_subset, conditions = c("tissue", "cell.type"),
#                             name_sep = "-", formula = ~ class, targets = targets_endothelial,
#                             fc_threshold = 1, pval_threshold = 0.05))
# )
