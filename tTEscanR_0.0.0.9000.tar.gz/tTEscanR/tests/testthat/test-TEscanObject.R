test_that("The tTEscanR object is correctly generated", {

  tTEobject <- Create_tTEscanR_Object(counts = mRNA_data, assay = "mRNA")

  expect_s4_class(object = tTEobject, class = "tTEscanR_Object")
  expect_equal(as.data.frame(tTEobject@assays$mRNA), mRNA_data)
  expect_no_error(IsIn_tTEscanR_Object(tTEobject, "mRNA"))

  expect_error(Create_tTEscanR_Object(counts = c(1, 2, 3, 4, 5), assay = "mRNA"))
  expect_error(Create_tTEscanR_Object(counts = mRNA_data))
  expect_error(Create_tTEscanR_Object(counts = mRNA_data, assay = mRNA))
})

test_that("The tTEscanR object is correctly updated", {

  tTEobject <- Create_tTEscanR_Object(counts = mRNA_data, assay = "mRNA")
  tTEobject <- Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA")

  expect_s4_class(object = tTEobject, class = "tTEscanR_Object")
  expect_equal(as.data.frame(tTEobject@assays$mRNA), mRNA_data)
  expect_equal(tTEobject@assays$tRNA, tRNA_data)

  expect_no_error(IsIn_tTEscanR_Object(tTEobject, "mRNA"))
  expect_no_error(IsIn_tTEscanR_Object(tTEobject, "tRNA"))
  expect_no_error(Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA",
                                        meta.data = list(ENSG_gene_names_mRNA_data), meta.data.ids = list("ENSG_gene_names_mRNA"), overwrite.assay = TRUE))

  expect_error(Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data))
  expect_error(Update_tTEscanR_Object(object = tTEobject, assay = "tRNA"))
  expect_error(Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA",
                                      meta.data = c(ENSG_gene_names_mRNA_data), meta.data.ids = c("ENSG_gene_names_mRNA")))
  expect_error(Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA",
                                     meta.data = list(ENSG_gene_names_mRNA_data)))
  expect_error(Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA",
                                      meta.data.ids = list("ENSG_gene_names_mRNA")))
  expect_error(Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA",
                                      meta.data = list(ENSG_gene_names_mRNA_data), meta.data.ids = list("ENSG_gene_names_mRNA")))
})

test_that("The metadata is correctly added to the tTEscanR object", {

  tTEobject <- Create_tTEscanR_Object(counts = mRNA_data, assay = "mRNA")

  expect_s4_class(object = tTEobject, class = "tTEscanR_Object")
  expect_equal(as.data.frame(tTEobject@assays$mRNA), mRNA_data)

  expect_no_error(Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA",
                                         meta.data = list(ENSG_gene_names_mRNA_data), meta.data.ids = list("ENSG_gene_names_mRNA")))

  expect_no_error(Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA",
                                         meta.data = list(ENSG_gene_names_mRNA_data), meta.data.ids = list("ENSG_gene_names_mRNA"),
                                         overwrite.metadata = TRUE))
  expect_no_error(Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA",
                                         meta.data = list(ENSG_gene_names_mRNA_data, short_gene_names_mRNA_data), meta.data.ids = list("ENSG_gene_names_mRNA", "short_gene_names_mRNA"),
                                         overwrite.metadata = TRUE))
  expect_no_error(Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA",
                                         meta.data = list(ENSG_gene_names_mRNA_data, short_gene_names_mRNA_data), meta.data.ids = list("ENSG_gene_names_mRNA", "short_gene_names_mRNA"),
                                         overwrite.metadata = FALSE))
  expect_no_error(Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA",
                                         meta.data = list(ENSG_gene_names_mRNA_data, short_gene_names_mRNA_data), meta.data.ids = list("ENSG_gene_names_mRNA", "ENSG_gene_names_mRNA"),
                                         overwrite.metadata = TRUE))

  expect_error(Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA",
                                      meta.data = list(ENSG_gene_names_mRNA_data, short_gene_names_mRNA_data), meta.data.ids = list("ENSG_gene_names_mRNA", "ENSG_gene_names_mRNA"),
                                      overwrite.metadata = FALSE))

})

test_that("The function to find sections in a tTEscanR object works", {

  tTEobject <- Create_tTEscanR_Object(counts = mRNA_data, assay = "mRNA")
  tTEobject <- Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA")

  expect_s4_class(object = tTEobject, class = "tTEscanR_Object")
  expect_equal(as.data.frame(tTEobject@assays$mRNA), mRNA_data)
  expect_equal(tTEobject@assays$tRNA, tRNA_data)

  expect_no_error(IsIn_tTEscanR_Object(object = tTEobject, section = "mRNA"))
  expect_no_error(IsIn_tTEscanR_Object(object = tTEobject, section = "tRNA"))
  expect_no_error(IsIn_tTEscanR_Object(object = tTEobject, section = "mRNA", update.assay = FALSE, overwrite = FALSE))
  expect_no_error(IsIn_tTEscanR_Object(object = tTEobject, section = "tRNA", update.assay = FALSE, overwrite = FALSE))

  expect_error(IsIn_tTEscanR_Object(object = tTEobject, section = mRNA))
  expect_error(IsIn_tTEscanR_Object(object = tTEobject, section = "CodonUsage"))
})

test_that("The metadata is correctly updated", {

  tTEobject <- Create_tTEscanR_Object(counts = mRNA_data, assay = "mRNA")
  # tTEobject <- Update_tTEscanR_Object(object = tTEobject, counts = tRNA_data, assay = "tRNA")

  expect_error(Update_tTEscanR_Object(object = tTEobject, meta.data = ENSG_gene_names_mRNA_data, meta.data.ids = "ENSG_gene_names_mRNA"))
  expect_no_error(Update_tTEscanR_Object(object = tTEobject, meta.data = list(ENSG_gene_names_mRNA_data), meta.data.ids = list("ENSG_gene_names_mRNA")))
  expect_no_error(Update_tTEscanR_Object(object = tTEobject, meta.data = list(ENSG_gene_names_mRNA_data, short_gene_names_mRNA_data), meta.data.ids = list("ENSG_gene_names_mRNA", "short_gene_names_mRNA")))

  tTEobject <- Update_tTEscanR_Object(object = tTEobject, meta.data = list(ENSG_gene_names_mRNA_data), meta.data.ids = list("ENSG_gene_names_mRNA"))

  expect_no_error(Update_tTEscanR_Object(object = tTEobject, meta.data = list(short_gene_names_mRNA_data), meta.data.ids = "short_gene_names_mRNA"))
  expect_no_error(Update_tTEscanR_Object(object = tTEobject, meta.data = list(ENSG_gene_names_mRNA_data), meta.data.ids = "ENSG_gene_names_mRNA_2"))
  expect_error(Update_tTEscanR_Object(object = tTEobject, meta.data = ENSG_gene_names_mRNA_data, meta.data.ids = "ENSG_gene_names_mRNA"))

})
