test_that("The gene annotation translation works", {

  expect_equal(rownames(TranslateGeneName(data_to_translate = mRNA_data_test, species = "hg38", position = "row", notation = "id")), ENSG_gene_names_mRNA_data) # short to ensg
  expect_equal(rownames(TranslateGeneName(data_to_translate = mRNA_data_test_translated, species = "hg38", position = "row", notation = "symbol")), short_gene_names_mRNA_data) # ensg to short
  expect_error(TranslateGeneName(data_to_translate = mRNA_data_test_translated, species = "hg38", position = "row", notation = "id"), "The genes are in the same annotation format: ") # short to short
  expect_error(TranslateGeneName(data_to_translate = mRNA_data_test, species = "hg38", position = "row", notation = "symbol"), "The genes are in the same annotation format: ") # ensg to ensg

  expect_equal(rownames(TranslateGeneName(data_to_translate = mRNA_data_test, translator_table = human_hg38_translator_table, position = "row", notation = "id")), ENSG_gene_names_mRNA_data) # short to ensg
  expect_equal(rownames(TranslateGeneName(data_to_translate = mRNA_data_test_translated, translator_table = human_hg38_translator_table, position = "row", notation = "symbol")), short_gene_names_mRNA_data) # ensg to short
  expect_error(TranslateGeneName(data_to_translate = mRNA_data_test_translated, translator_table = human_hg38_translator_table, position = "row", notation = "id"), "The genes are in the same annotation format: ") # short to short
  expect_error(TranslateGeneName(data_to_translate = mRNA_data_test, translator_table = human_hg38_translator_table, position = "row", notation = "symbol"), "The genes are in the same annotation format: ") # ensg to ensg

  expect_equal(colnames(TranslateGeneName(data_to_translate = t(mRNA_data_test), translator_table = human_hg38_translator_table, position = "column", notation = "id")), ENSG_gene_names_mRNA_data) # short to ensg
  expect_equal(colnames(TranslateGeneName(data_to_translate = t(mRNA_data_test_translated), translator_table = human_hg38_translator_table, position = "column", notation = "symbol")), short_gene_names_mRNA_data) # ensg to short
  expect_error(TranslateGeneName(data_to_translate = t(mRNA_data_test_translated), translator_table = human_hg38_translator_table, position = "column", notation = "id"), "The genes are in the same annotation format: ") # short to short
  expect_error(TranslateGeneName(data_to_translate = t(mRNA_data_test), translator_table = human_hg38_translator_table, position = "column", notation = "symbol"), "The genes are in the same annotation format: ") # ensg to ensg

  expect_error(TranslateGeneName(data_to_translate = mRNA_data_test, translator_table = human_hg38_translator_table, position = "row", notation = "short"), "Incorrect `notation` input value.") # wrong notation parameter

})

test_that("The gene annotation of two vectors is correctly determined", {

  expect_message(CheckGeneAnnotation(vector1 = ENSG_gene_names_mRNA_data, vector2 = ENSG_gene_names_mRNA_data, translate = FALSE), "Both vectors are in the same format: ")
  expect_message(CheckGeneAnnotation(vector1 = short_gene_names_mRNA_data, vector2 = short_gene_names_mRNA_data, translate = FALSE), "Both vectors are in the same format: ")
  expect_error(CheckGeneAnnotation(vector1 = ENSG_gene_names_mRNA_data, vector2 = short_gene_names_mRNA_data, translate = FALSE), "The vectors have different formats")
  expect_error(CheckGeneAnnotation(vector1 = short_gene_names_mRNA_data, vector2 = ENSG_gene_names_mRNA_data, translate = FALSE), "The vectors have different formats")
  expect_equal(CheckGeneAnnotation(vector1 = short_gene_names_mRNA_data, vector2 = ENSG_gene_names_mRNA_data, translate = TRUE), "Ensembl ID")
  expect_equal(CheckGeneAnnotation(vector1 = ENSG_gene_names_mRNA_data, vector2 = short_gene_names_mRNA_data, translate = TRUE), "Gene Symbol")

})

test_that("The gene annotation is correctly identified", {

  expect_no_message(IsEnsemblID(gene_vector = ENSG_gene_names_mRNA_data, action = "check"))
  expect_no_message(IsEnsemblID(gene_vector = short_gene_names_mRNA_data, action = "check"))
  expect_equal(IsEnsemblID(gene_vector = ENSG_gene_names_mRNA_data, action = "translate"), "Ensembl ID")
  expect_equal(IsEnsemblID(gene_vector = short_gene_names_mRNA_data, action = "translate"), "Gene Symbol")

  expect_error(IsEnsemblID(gene_vector = c(ENSG_gene_names_mRNA_data, short_gene_names_mRNA_data), action = "check"), "inconsistencies")
  expect_error(IsEnsemblID(gene_vector = c(ENSG_gene_names_mRNA_data, short_gene_names_mRNA_data), action = "check"), "inconsistencies")
  expect_error(IsEnsemblID(gene_vector = c(ENSG_gene_names_mRNA_data, short_gene_names_mRNA_data), action = "translate"), "inconsistencies")
  expect_error(IsEnsemblID(gene_vector = c(ENSG_gene_names_mRNA_data, short_gene_names_mRNA_data), action = "translate"), "inconsistencies")
  expect_equal(IsEnsemblID(gene_vector = c(ENSG_gene_names_mRNA_data, short_gene_names_mRNA_data), action = "translate", notation = "id"), "Gene Symbol")
  expect_equal(IsEnsemblID(gene_vector = c(ENSG_gene_names_mRNA_data, short_gene_names_mRNA_data), action = "translate", notation = "symbol"), "Ensembl ID")
})

test_that("The default data is correctly loaded", {

  expect_equal(SelectDefaultData(action = "translator_table", species = "hg38"), human_hg38_translator_table) # data loaded human
  expect_equal(SelectDefaultData(action = "translator_table", species = "mm39"), mouse_mm39_translator_table) # data loaded mouse
  expect_error(SelectDefaultData(action = "translator_table", species = "hg37")) # error wrong species label
  expect_error(SelectDefaultData(species = "hg38")) # error need to specify action
  expect_error(SelectDefaultData(action = "translator_table")) # error need to specify a species

  expect_equal(SelectDefaultData(action = "codon_freq", species = "hg38", filter = "length"), human_codon_freq_per_gene_table_length)
  expect_equal(SelectDefaultData(action = "codon_freq", species = "hg38", filter = "canonical"), human_codon_freq_per_gene_table_canonical)
  expect_equal(SelectDefaultData(action = "codon_freq", species = "mm39", filter = "length"), mouse_codon_freq_per_gene_table_length)
  expect_equal(SelectDefaultData(action = "codon_freq", species = "mm39", filter = "canonical"), mouse_codon_freq_per_gene_table_canonical)
  expect_error(SelectDefaultData(action = "codon_freq", species = "mm39"))
  expect_error(SelectDefaultData(action = "codon_freq", species = "hg38"))

  expect_error(SelectDefaultData(action = "mRNA"))
  expect_error(SelectDefaultData(action = "codon_freq", species = "mm39", filter = "larger"))

})

test_that("The data loaded has a correct format", {

  expect_error(IdentifyInputFormat(data = list(4, 5, 6, 7, 8)))
  expect_error(IdentifyInputFormat(data = c()))
  expect_no_error(IdentifyInputFormat(data = mRNA_data_test))
  expect_no_error(IdentifyInputFormat(data = ENSG_gene_names_mRNA_data))

})
