## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----echo = FALSE, results = 'asis'-------------------------------------------
cat('
<style>
.note {
  background-color: #f6e8c3;
  border-left: 5px solid #dfc27d;
  padding: 1em;
  margin: 1em 0;
  border-radius: 4px;
}
.warning {
  background-color: #fff3cd;
  border-left: 5px solid #ff9800;
  padding: 1em;
  margin: 1em 0;
  border-radius: 4px;
}
</style>
')

## ----setup, message = FALSE, warning = FALSE----------------------------------
# install.packages("/avarassanchez/tTEscanR")
devtools::load_all()
library(tTEscanR)

## ----message = FALSE, warning = FALSE-----------------------------------------
library(biomaRt)

## ----datasets_ensembl, message = TRUE, warning = FALSE, eval = FALSE----------
# datasets <- biomaRt::listDatasets(useEnsembl(biomart = "ensembl"))

## ----canonical_codon_freq_per_gene, message = TRUE, warning = FALSE, eval = FALSE----
# codon_freq_results_canonical <- GetCodonFreq(dataset_name = "hsapiens_gene_ensembl", filter = "canonical", retain.geneversion = TRUE,
#                                              retain.mitochondrial = FALSE, out_format = "external_gene_name")

## ----canonical_codon_freq_per_gene_results, message = TRUE, warning = FALSE, eval = FALSE----
# hg38_codon_freq_table_canonical <- codon_freq_results_canonical[[2]]
# hg38_gene_translator_table_canonical <- codon_freq_results_canonical[[1]]

## ----length_codon_freq_per_gene, message = TRUE, warning = FALSE, eval = FALSE----
# codon_freq_results_length <- GetCodonFreq(dataset_name = "mmusculus_gene_ensembl", filter = "length",
#                                           retain.mitochondrial = FALSE, out_format = "ensembl_gene_id")

## ----length_codon_freq_per_gene_results, message = TRUE, warning = FALSE, eval = FALSE----
# mm39_codon_freq_table_length <- codon_freq_results_length[[2]]
# mm39_gene_translator_table_length <- codon_freq_results_length[[1]]

