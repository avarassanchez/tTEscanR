## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----echo = FALSE, results = 'asis'-------------------------------------------
cat('
<style>
.note {
  background-color: #f6e8c3;
  border-left: 5px solid #dfc27d;
  padding: 1em;
  margin: 1em 0;
  border-radius: 4px;
}
.warning {
  background-color: #fff3cd;
  border-left: 5px solid #ff9800;
  padding: 1em;
  margin: 1em 0;
  border-radius: 4px;
}
</style>
')

## ----setup, message = FALSE, warning = FALSE----------------------------------
# install.packages("/avarassanchez/tTEscanR")
devtools::load_all()
library(tTEscanR)

## ----load_data_mRNA, message = FALSE, warning = FALSE-------------------------
data(subset_mRNA_data)

## ----load_data_tRNA, message = FALSE, warning = FALSE-------------------------
data(subset_tRNA_data)

## ----filter_tRNAs, message = FALSE, warning = FALSE---------------------------
filtered_tRNA_data <- Filter_tRNACuts(data = subset_tRNA_data, cutoff = 5000)

## ----metadata_definition, message = FALSE, warning = FALSE--------------------
data(metadata)

## ----create_tTEscanR_object, message = FALSE, warning = FALSE-----------------
# Adding the mRNA and tRNA datasest to the object
tTEobject <- Create_tTEscanR_Object(counts = list(subset_mRNA_data, subset_tRNA_data), assay = list("mRNA", "tRNA"), 
                                    meta.data = metadata, meta.data.ids = "ConditionsLabels") 

## ----update_tTEscanR_object, message = FALSE, warning = FALSE-----------------
# Updating the object created before some metadata for reference
matching_celltypes <- intersect(colnames(subset_mRNA_data), colnames(subset_tRNA_data))

tTEobject <- Update_tTEscanR_Object(object = tTEobject, meta.data = matching_celltypes, 
                                    meta.data.ids = "matching_celltypes", overwrite_metadata = TRUE)

## ----codon_usage, message = FALSE, warning = FALSE----------------------------
# We first need to add the correction factor to the tTEscanR object
# It has to be stored as CorrectionFactor
tTEobject <- Update_tTEscanR_Object(object = tTEobject, meta.data = "tissue", meta.data.ids = "CorrectionFactor")

tTEobject <- ComputeCodonUsage(object = tTEobject, codon_freq = NULL, species = "hg38", 
                               additional_metrics = TRUE, overwrite_assay = TRUE, overwrite_metadata = TRUE)

## ----correlation_plot_mean, message = FALSE, warning = FALSE------------------
# Transforming the data
mean_codon_usage <- tTEobject@meta.data$CodonUsage_AdditionalMetrics$MeanCodonUsage
exonic_background <- tTEobject@meta.data$CodonUsage_AdditionalMetrics$CodonExonicBackground
exonic_background <- as.data.frame(exonic_background)
correlation_mean_background <- cbind(mean_codon_usage, exonic_background)

tTE_CorrelationPlot(data = correlation_mean_background, plot = "MeanCodonUsage",
                    x_axis_col = "mean_usage_across_conditions", y_axis_col = "exonic_background",
                    extra_val = tTEobject@meta.data$CodonUsage_AdditionalMetrics$MeanCodonCorr,
                    condition_col = "feature", # Here feature = codons
                    add_titles = TRUE, show_legend = "none")

## ----codon_pool_contribution, message = FALSE, warning = FALSE----------------
tTEobject <- ShowPoolContribution(object = tTEobject, N = 10, species = "hg38", overwrite_assay = TRUE, overwrite_metadata = TRUE)

## ----correlation_plot_diversity, message = FALSE, warning = FALSE-------------
# Transforming the data
codon_pool_diversity <- tTEobject@meta.data$CodonPoolContribution_Results$top10GenesCodonPoolDiversity
colnames(codon_pool_diversity) <- c("condition", "original_top_contribution", "baseline_correlation")
codon_pool_diversity <- codon_pool_diversity %>%
  tidyr::separate(.data$condition, into = c("tissue", "cell_type"), sep = "-")

tTE_CorrelationPlot(data = codon_pool_diversity, plot = "PoolDiversity",
                    x_axis_col = "original_top_contribution", y_axis_col = "baseline_correlation", 
                    condition_col = "tissue", label_col = "cell_type", show_legend = "right")

## ----anticodon_usage, message = FALSE, warning = FALSE------------------------
tTEobject <- ComputeAnticodonUsage(object = tTEobject)

## ----ammino_acid_demand, message = FALSE, warning = FALSE, eval = FALSE-------
# # Computing AA demand
# tTEobject <- ComputeAAUsage(object = tTEobject, level = "demand")

## ----ammino_acid_supply, message = FALSE, warning = FALSE, eval = FALSE-------
# # Computing AA supply
# tTEobject <- ComputeAAUsage(object = tTEobject, level = "supply")

## ----ammino_acid, message = FALSE, warning = FALSE----------------------------
# Computing simultaneously AA demand and supply
tTEobject <- ComputeAAUsage(object = tTEobject, level = "both", overwrite_assay = TRUE)

## ----tTE_score_codon, message = FALSE, warning = FALSE,eval = FALSE-----------
# # Computing tTE at the codon-anticodon level
# tTEobject <- Compute_tTE(object = tTEobject, level = "codon")

## ----tTE_score_aa, message = FALSE, warning = FALSE, eval = FALSE-------------
# # Computing tTE at the AA demand-supply level
# tTEobject <- Compute_tTE(object = tTEobject, level = "aa")

## ----tTE_score, message = FALSE, warning = FALSE------------------------------
# Computing simultaneously tTE at the codon-anticodon and AA demand-supply levels
tTEobject <- Compute_tTE(object = tTEobject, level = "both", overwrite = TRUE)

## -----------------------------------------------------------------------------
conditions_metadata <- tTEobject@meta.data$ConditionsLabels

## ----fig.width =  6, fig.height = 4, fig.align = 'center'---------------------
# Use tTEobject@meta.data$tTEresults_codon to assess the codon-anticodon level
tTE_ScoresPlot(data = tTEobject@meta.data$tTEresults_AA, metadata = conditions_metadata, 
               index_col = "conditions", class_col = "tissue", add_stats = FALSE)

## -----------------------------------------------------------------------------
conditions_metadata$group <- "other"
conditions_metadata$group[grep("neuron", conditions_metadata$conditions)] <- "neurons"
conditions_metadata$group[grep("ENS neuron", conditions_metadata$conditions)] <- "other"

## ----fig.width =  6, fig.height = 4, fig.align = 'center'---------------------
# Use tTEobject@meta.data$tTEresults_codon to assess the codon-anticodon level
tTE_ScoresPlot(data = tTEobject@meta.data$tTEresults_AA, metadata = conditions_metadata, 
               index_col = "conditions", class_col = "group", add_stats = TRUE)

## -----------------------------------------------------------------------------
# Other outputs that could be analyzed:
  # mRNA = tTEobject@assays$mRNA
  # CodonUsage = tTEobject@assays$CodonUsage
  # tRNA = tTEobject@assays$tRNA
  # AnticodonUsage = tTEobject@assays$AnticodonUsage

AA_results <- list(AADemand = tTEobject@assays$AADemand, AASupply = tTEobject@assays$AASupply)

## ----message = FALSE, warning = FALSE, eval = FALSE---------------------------
# all_DESeq2_results <- RunDEAnalysis(list_data = AA_results, metadata = metadata, heatmap = TRUE, dim_reduct =  "PCA", numPC = 2, batch = "tissue",
#                                     color_factor = "tissue", show_legend = "right", label_factor = "cell.type")
# 
# grid.draw(all_DESeq2_results$plots$AADemand$heatmap) # Visualize the heatmap plot
# all_DESeq2_results$plots$AADemand$exploratory$ElbowPlot # Visualize the elbow plot
# all_DESeq2_results$plots$AADemand$exploratory$PC1_vs_PC2 # Visualize the PCA plot

