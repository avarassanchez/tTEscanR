#' @importFrom methods setClass new validObject
#'
NULL

#' The tTEscanR Class
#'
#' @description
#' The TEscanR object is a representation of mRNA and tRNA expression data at the codon and amino acid levels.
#' It stores all information associated with the dataset, including data, annotations and analyses.
#' All that is needed to construct a tTEscanR object is an expression matrix (rows are features, columns as conditions).
#'
#' @slot assays A list of assays for this project containing the mRNA information.
#' @slot meta.data Meta-information associated with the assay.
#'
#' @name tTEscanR_Object-class
#' @rdname tTEscanR_Object-class
#' @exportClass tTEscanR_Object

setClass(Class = 'tTEscanR_Object',
         slots = c(assays = 'list',
                   meta.data = 'list'))


#' Create a tTEscanR Object
#'
#' @description
#' Initializes and returns a new \code{tTEscanR_Object}.
#'
#' @param counts A matrix containing the expression data to be included in the \code{tTEscanR_Object} object (rows are features, columns as conditions).
#' @param assay A character string specifying the name of the assay for the \code{counts}.
#' @param meta.data (Optional) Meta-information (a \code{list}) associated with the assay.
#' @param meta.data.ids (Optional) Meta-information (a \code{list}) to specify the identifier of the \code{meta.data} (required if \code{meta.data} is given).
#' @param verbose Logical; if TRUE, displays information messages.
#'
#' @return A \code{tTEscanR_Object} object.
#' @export
#'
#' @examples
#' data(mRNA_data)
#' data(tRNA_data)
#'
#' tTEobj_mRNA <- Create_tTEscanR_Object(counts = mRNA_data, assay = "mRNA")
#' tTEobj_tRNA <- Create_tTEscanR_Object(counts = tRNA_data, assay = "tRNA")
#' tTEobj_tRNA <- Create_tTEscanR_Object(counts = list(mRNA_data, tRNA_data),
#'                                       assay = c("mRNA", "tRNA"))

Create_tTEscanR_Object <- function(counts,
                                   assay,
                                   meta.data = NULL,
                                   meta.data.ids = NULL,
                                   verbose = TRUE){

  if (verbose) message("Checking the format of the input data.")
  input_format <- IdentifyInputFormat(data = counts)
  assay.list <- list()

  if (input_format == "list"){
    if (verbose) message("Multiple assay addition.")
    if (length(counts) != length(assay)) stop("The lengths of `counts` and `assay` must be the same.")

    for (i in 1:length(counts)){
      if (is.data.frame(counts[[i]])) {
        counts_matrix <- as.matrix(counts[[i]])
      } else {
        counts_matrix <- counts[[i]]
      }

      assay.list[i] <- list(counts[[i]])
      names(assay.list)[i] <- assay[[i]]

      object <- suppressWarnings(expr = new(
        Class = 'tTEscanR_Object',
        assays = assay.list
      ))
    }

  } else {
    if (is.data.frame(counts)) counts <- as.matrix(counts)

    assay.list <- list(counts)
    names(assay.list) <- assay

    object <- suppressWarnings(expr = new(
      Class = 'tTEscanR_Object',
      assays = assay.list))
  }

  if (!is.null(meta.data) && !is.null(meta.data.ids)){
    for (i in 1:length(meta.data)){
      object <- Update_tTEscanR_ObjectMetadata(object = object,
                                               meta.data = meta.data[[i]],
                                               meta.data.ids = meta.data.ids[[i]],
                                               verbose = verbose)
    }
  } else if (is.null(meta.data) && !is.null(meta.data.ids)){
     stop("The input parameter `meta.data` is empty.")
  } else if (!is.null(meta.data) && is.null(meta.data.ids)){
     stop("The input parameter `meta.data.ids` is empty.")
  }

  validObject(object = object) # Validate and return the object
  return(object)
}

#' Update a tTEscanR Object
#'
#' @param object An existing  \code{tTEscanR_Object}.
#' @param counts A matrix containing the expression data to be included in the \code{tTEscanR_Object} object (rows are features, columns as conditions).
#' @param assay A character string specifying the name of the assay for the \code{counts}.
#' @param meta.data (Optional) Meta-information (a \code{list}) associated with the assay.
#' @param meta.data.ids (Optional) Meta-information (a \code{list}) to specify the identifier of the \code{meta.data} (required if \code{meta.data} is given).
#' @param overwrite.assay Logical; if TRUE, overwrites the assay (if already present in the \code{tTEscanR_Object}).
#' @param overwrite.metadata Logical; if TRUE, overwrites the metadata (if already present in the \code{tTEscanR_Object}).
#' @param verbose Logical; if TRUE, displays information messages.
#'
#' @return A \code{tTEscanR_Object} object.
#' @export
#'
#' @examples
#' data(mRNA_data)
#' data(tRNA_data)
#' TEobj <- Create_tTEscanR_Object(counts = mRNA_data, assay = "mRNA")
#' TEobj <- Update_tTEscanR_Object(object = TEobj, counts = tRNA_data, assay = "tRNA")

Update_tTEscanR_Object <- function(object,
                                   counts = NULL,
                                   assay = NULL,
                                   meta.data = NULL,
                                   meta.data.ids = NULL,
                                   overwrite.assay = FALSE,
                                   overwrite.metadata = FALSE,
                                   verbose = TRUE){

  if (!inherits(object, 'tTEscanR_Object')){
    stop("`object` must be a tTEscanR_Object.")
  }

  if (!is.null(counts) && !is.null(assay)){
    if (verbose) message("Checking the format of the input data.")
    input_format <- IdentifyInputFormat(data = counts)
    assay.list <- list()

    if (input_format == "list"){
      if (verbose) message("Multiple assay addition.")
      if (length(counts) != length(assay)) stop("The lengths of `counts` and `assay` must be the same.")

      for (i in 1:length(counts)){
        current.assay <- assay[[i]]
        IsIn_tTEscanR_Object(object = object, section = current.assay, update.assay = TRUE, overwrite = overwrite.assay, verbose = verbose)
        object@assays[[current.assay]] <- counts
      }
    } else {
      IsIn_tTEscanR_Object(object = object, section = assay, update.assay = TRUE, overwrite = overwrite.assay, verbose = verbose)
      object@assays[[assay]] <- counts
    }

  } else if (is.null(counts) && !is.null(assay)){
    stop("The input parameter `counts` is empty.")
  } else if (!is.null(counts) && is.null(assay)){
    stop("The input parameter `assay` is empty.")
  }

  if (!is.null(meta.data) && !is.null(meta.data.ids)){
    for (i in 1:length(meta.data)){

      current.id <- meta.data.ids[[i]]
      ExistMetadata_tTEscanR_Object(object = object,
                                    section = current.id,
                                    update.metadata = TRUE,
                                    overwrite = overwrite.metadata,
                                    verbose = verbose)

      object@meta.data[[current.id]] <- meta.data[[i]]
      validObject(object = object)
    }
  } else if (is.null(meta.data) && !is.null(meta.data.ids)){
    stop("The input parameter `meta.data` is empty.")
  } else if (!is.null(meta.data) && is.null(meta.data.ids)){
    stop("The input parameter `meta.data.ids` is empty.")
  }

  validObject(object = object)
  return(object)
}
