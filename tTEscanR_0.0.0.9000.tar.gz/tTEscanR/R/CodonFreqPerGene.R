#' @importFrom utils setTxtProgressBar txtProgressBar
NULL

ExtractGenes <- function(ensembl,
                         filter,
                         verbose = TRUE){

  if (verbose) message("- Retriving protein coding genes & filtering out mitochondrial genes.")
  prot_coding_ensembl <- biomaRt::getBM(attributes = c("ensembl_gene_id", "ensembl_transcript_id", "chromosome_name",
                                                       "external_gene_name", "transcript_start", "transcript_end",
                                                       "transcript_is_canonical"),
                                        filters = c("biotype", "chromosome_name"),
                                        values = list("protein_coding", setdiff(c(1:22, "X", "Y"), "MT")),
                                        mart = ensembl)

  if (filter == "length"){
    if (verbose) message("- Computing the length of each transcript.")
    prot_coding_ensembl$transcript_length <- as.numeric(abs((prot_coding_ensembl$transcript_start+1) - prot_coding_ensembl$transcript_end))
    if (verbose) message("- Selecting (if many) the largest transcript for each gene.")
    prot_coding_ensembl <- prot_coding_ensembl[order(prot_coding_ensembl$ensembl_gene_id, -prot_coding_ensembl$transcript_length), ]
    prot_coding_ensembl <- prot_coding_ensembl[!duplicated(prot_coding_ensembl$ensembl_gene_id), ]

  } else if (filter == "canonical"){
    if (verbose) message("- Selecting (if many) the canonical transcript for each gene.")
    prot_coding_ensembl <- subset(prot_coding_ensembl, prot_coding_ensembl$transcript_is_canonical == 1)
  }

  return(prot_coding_ensembl)
}

ExtractSequences <- function(transcripts,
                             ensembl){

  transcript_sequences <- biomaRt::getSequence(id = transcripts,
                                               type = "ensembl_transcript_id",
                                               seqType = "coding", mart = ensembl)
  return(transcript_sequences)
}

CodonOccurrences <- function(sequence) {

  sequence <- substr(sequence, 1, (nchar(sequence) %/% 3) * 3)
  if (nchar(sequence) %% 3 != 0) {
    stop("The sequence length is not a multiple of 3.")
  }
  codons <- substring(sequence, seq(1, nchar(sequence) - 2, 3), seq(3, nchar(sequence), 3))
  codon_counts <- table(codons)

  return(as.data.frame(codon_counts)) # Add the codons as a column not as rownames
}

#' Extract Codon Composition of DNA Sequence
#'
#' @param sequences Set of DNA sequences.
#' @param verbose A boolean parameter to specify if the messages within the function should be display.
#'
#' @return Codon frequency per gene table.
#' @export
#'

ExtractCodonComposition <- function(sequences,
                                    verbose = TRUE){

  n <- nrow(sequences)
  pb <- txtProgressBar(min = 0, max = n, style = 3)

  for (i in 1:n) {
    transcript_id <- sequences$ensembl_transcript_id[i]
    sequence <-sequences$coding[i]

    codon_counts <- CodonOccurrences(sequence)
    colnames(codon_counts) <- c("codons", transcript_id)

    if (i == 1) {
      codon_freq_per_gene_matrix <- codon_counts
    } else {
      codon_freq_per_gene_matrix <- merge(codon_freq_per_gene_matrix, codon_counts, all = TRUE)
    }

    if (ncol(codon_freq_per_gene_matrix) == 0 || nrow(codon_freq_per_gene_matrix) == 0) {
      stop("Incorrect dimensions.")
    }
    setTxtProgressBar(pb, i)
  }

  close(pb)

  rownames(codon_freq_per_gene_matrix) <- codon_freq_per_gene_matrix[, 1]
  codon_freq_per_gene_matrix[is.na(codon_freq_per_gene_matrix)] <- 0
  codon_freq_per_gene_matrix <- codon_freq_per_gene_matrix[, 2:ncol(codon_freq_per_gene_matrix)]

  codonsN <- grep(pattern = "N", x = rownames(codon_freq_per_gene_matrix))
  if (length(codonsN) != 0){
    if (verbose) {
      message("- There are codons with unknown bases (N nucleotides).")
      message("- These codons will be removed.")
    }
    codon_freq_per_gene_matrix <- codon_freq_per_gene_matrix[-codonsN, ]
  }

  return(codon_freq_per_gene_matrix)
}


#' Compute Codon Frequency per Gene Table
#'
#' @param dataset_name Species name of Ensembl dataset.
#' @param transcripts Input a vector of transcript names if desired for the selection; defaults to NULL, the largest transcript will be selected.
#' @param filter A character string specifying the criteria to select the transcript of a gene if many are available.
#' @param annotation Boolean variable to indicate if the gene annotation translator table should be included as output.
#' @param verbose A boolean parameter to specify if the messages within the function should be display.
#'
#' @return Codon frequency per gene table.
#' @export
#'

ObtainCodonFreqPerGene <- function(dataset_name,
                                   transcripts = NULL,
                                   filter = NULL,
                                   annotation = TRUE,
                                   verbose = TRUE){

  if (verbose) message("1. Retrieving Ensembl dataset.")
  ensembl <- biomaRt::useEnsembl(biomart = "ensembl", dataset = dataset_name)

  if (is.null(transcripts)){
    if (filter != "length" && filter != "canonical"){
      stop("Please specify `length` or `canonical` as `filter` input parameter.")
    }
    transcripts <- ExtractGenes(ensembl = ensembl, filter = filter)
    translator_table <- data.frame(transcripts$ensembl_transcript_id, transcripts$ensembl_gene_id, transcripts$external_gene_name)
    transcripts <- transcripts$ensembl_transcript_id
  }

  if (verbose) message("2. Extracting the genomic sequence of each transcript.")
  transcript_sequences <- ExtractSequences(transcripts = transcripts, ensembl = ensembl)

  unavailable <- which(transcript_sequences$coding == "Sequence unavailable")

  if (length(unavailable) != 0){
    if (verbose) {
      message(paste("- There are", length(unavailable), "transcripts which sequence is unavailable."))
      message("- These transcripts will be removed.")
    }
    transcript_sequences <- transcript_sequences[-unavailable, ]
  }

  if (verbose){
    message(paste("- Number of protein coding transcripts:", nrow(transcript_sequences)))
    message("3. Retrieving the codon composition of each transcript.")
  }
  codon_freq_per_gene_matrix <- ExtractCodonComposition(sequences = transcript_sequences)

  if (verbose) message("4. Translating the transcript identifiers to their corresponding Ensembl gene identifiers.")
  tr <- setNames(translator_table[ ,2], nm = translator_table[ ,1])
  translated_transcripts <- dplyr::recode(colnames(codon_freq_per_gene_matrix), !!!tr)
  colnames(codon_freq_per_gene_matrix) <- translated_transcripts

  if (verbose) message("5. Outputs:")
  if (annotation == TRUE){
    if (verbose) {
      message("- Codon frequency per gene matrix.")
      message("- Gene annotation translator table.")
    }
    return(list(codon_freq_per_gene_matrix, translator_table[, 2:3]))
  } else {
    if (verbose) message("- Codon frequency per gene matrix.")
    return(codon_freq_per_gene_matrix)
  }
}

