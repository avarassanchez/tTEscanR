utils::globalVariables("condition")
NULL

ComputeTopNGenes <- function(data,
                             codon_freq,
                             mRNAs_in_common,
                             N){

  codon_pool_contribution <- as.matrix(data[mRNAs_in_common, ]) * colSums(codon_freq[, mRNAs_in_common])
  codon_pool_contribution <- sweep(codon_pool_contribution, 2, colSums(codon_pool_contribution), FUN="/")

  codon_pool_contribution_of_top_N_genes <- numeric(length(colnames(data)))
  top_N_codon_pool_contributors_per_condition <- matrix(data = 0, nrow = N, ncol = length(colnames(data)))

  for (i in 1:length(colnames(data))) {
    top_N_genes <- sort(codon_pool_contribution[, i], decreasing = TRUE)[1:N]
    codon_pool_contribution_of_top_N_genes[i] <- sum(top_N_genes)
    top_N_codon_pool_contributors_per_condition[, i] <- names(top_N_genes)
  }

  # Report the top N genes that have been selected
  message(paste("The top ", N, "genes are: "))
  for (i in 1:length(top_N_genes)){
    message(paste(names(top_N_genes[i]), unname(top_N_genes[i]), sep = ": "))
  }
  message("\n")

  return(list(codon_pool_contribution_of_top_N_genes, top_N_codon_pool_contributors_per_condition))
}

ComputeWithoutTopNGenes <- function(data,
                                    codon_freq,
                                    mean_codon_usage,
                                    top_N_codon_pool_contributors){

  # removed_top_N_genes_size_corrected <- data_mRNA[object@meta.data$mRNAsInCommon, ]

  for (i in 1:length(colnames(data))) {
    select_condition_top_N_contributors <- top_N_codon_pool_contributors[, i]
    data[select_condition_top_N_contributors, ] <- 0
  }

  removed_top_N_genes_codon_usage <- as.matrix(codon_freq) %*% as.matrix(data)
  removed_top_N_genes_codon_usage <- sweep(removed_top_N_genes_codon_usage, 2, colSums(removed_top_N_genes_codon_usage), "/")

  removed_top_N_genes_correlation_to_mean_codon_usage <- numeric(length(colnames(data)))
  names(removed_top_N_genes_correlation_to_mean_codon_usage) <- colnames(data)

  for (i in 1:length(colnames(data))) {
    removed_top_N_genes_correlation_to_mean_codon_usage[i] <- cor(removed_top_N_genes_codon_usage[, i], mean_codon_usage$mean_codon_usage_across_conditions)
  }

  return(removed_top_N_genes_correlation_to_mean_codon_usage)
}

ComputeIndividualGeneCorrelation <- function(data,
                                             codon_usage_size_corrected,
                                             mean_codon_usage){

  condition_correlations_to_mean_codon_usage <- numeric(length(colnames(data)))
  names(condition_correlations_to_mean_codon_usage) <- colnames(data)

  for (i in 1:length(colnames(data))) {
    select_condition_codon_usage <- dplyr::filter(codon_usage_size_corrected, condition == colnames(data)[i])$usage
    condition_correlations_to_mean_codon_usage[i] <- cor(mean_codon_usage$mean_codon_usage_across_conditions, select_condition_codon_usage, method = "spearman")
  }

  return(condition_correlations_to_mean_codon_usage)
}

CodonPoolDiverstity <- function(labels,
                                codon_pool_contribution,
                                correlation_to_mean){

  codon_pool_diversity_vs_correlation <- tibble::tibble(
    condition = labels,
    codon_diversity = 1 - codon_pool_contribution,
    correlation = correlation_to_mean
  )

  correlation_value <- round(cor(codon_pool_diversity_vs_correlation$codon_diversity, codon_pool_diversity_vs_correlation$correlation), 3)

  return(correlation_value)
}

#' Examine the Codon Pool Contribution
#'
#' @param object A \code{tTEscanR_Object} containing a mRNA and a codon usage assay.
#' @param N Number of top genes to consider in the codon pool contribution.
#' @param codon_freq Optional codon frequency per gene table (a \code{meta.frame}) associated with the \code{object}.
#' @param species A character string specifying the species' reference genome version (required if \code{codon_freq} is NULL).
#' @param filter A optional character string specifying the criteria to select the transcript of a gene if many are available (required if \code{codon_freq} is NULL).
#' @param conditions A vector with the labels for each section of the conditions labels.
#' @param name_sep Specification of the notation separation used in the condition labels to run a DESeq2 analysis.
#' @param formula Design formula to use for the DESeq2 analysis. The name of the factors needs to be consistent with the column names of the \code{conditions}.
#' @param overwrite.assay A boolean parameter to specify if already existing assays would be updated.
#' @param overwrite.metadata A boolean parameter to specify if already existing metadata would be updated.
#'
#' @return An updated \code{tTEscanR_Object} containing a new layer of information representing the codon pool contribution.
#' @export
#'

ExamineCodonPoolContribution <- function(object,
                                         N = 10,
                                         codon_freq = NULL,
                                         species = NULL,
                                         filter = filter,
                                         conditions,
                                         name_sep,
                                         formula,
                                         overwrite.assay = FALSE,
                                         overwrite.metadata = FALSE){

  message("1. Evaluating the input tTEscanR object.")
  if (!inherits(object, 'tTEscanR_Object')){
    stop("`object` must be a tTEscanR object.")
  }

  IsIn_tTEscanR_Object(object = object, section = "mRNA")
  IsIn_tTEscanR_Object(object = object, section = "CodonUsage")
  IsIn_tTEscanR_Object(object = object, section = "MeanCodonUsage")
  ExistMetadata_tTEscanR_Object(object = object, section = "mRNAsInCommon")

  # Load variables from the object
  data_mRNA <- ComputeSizeCorrection(data = object@assays$mRNA,
                                     runDESeq2 = TRUE,
                                     conditions = conditions,
                                     name_sep = name_sep,
                                     formula = formula)

  codon_frequency_per_gene_table <- CheckCodonFreqTable(data = codon_freq, species = species, filter = filter)
  codon_usage_size_corrected <- ComputeSizeCorrection(data = object@assays$CodonUsage,
                                                      runDESeq2 = TRUE,
                                                      conditions = conditions,
                                                      name_sep = name_sep,
                                                      formula = formula)
  codon_usage_size_corrected <- DataToLongFormat(data = codon_usage_size_corrected,
                                                 rownames_to_column = "codon",
                                                 names_to = "condition",
                                                 values_to = "usage")

  message("2. Computing each gene's codon pool contribution for each condition.")
  extract_topN_genes <- ComputeTopNGenes(data = data_mRNA,
                                         codon_freq = codon_frequency_per_gene_table,
                                         mRNAs_in_common = object@meta.data$mRNAsInCommon,
                                         N = 10)
  codon_pool_contribution_of_top_N_genes <- extract_topN_genes[[1]]
  top_N_codon_pool_contributors_per_condition <- extract_topN_genes[[2]]

  message("3. Calculate each condition's correlation to mean codon usage across conditions.")
  condition_correlations_to_mean_codon_usage <- ComputeIndividualGeneCorrelation(data = data_mRNA,
                                                                                 codon_usage_size_corrected = codon_usage_size_corrected,
                                                                                 mean_codon_usage = object@assays$MeanCodonUsage)

  message("4. Examining correlation between codon pool diversity and correlation to mean codon usage.")
  correl_topN <- CodonPoolDiverstity(labels = colnames(object@assays$mRNA),
                                     codon_pool_contribution = codon_pool_contribution_of_top_N_genes,
                                     correlation_to_mean = condition_correlations_to_mean_codon_usage)

  # Remove expression of top N codon pool contributors (so their codon pool contribution becomes 0)
  message(paste("5. Calculating and examining correlation removing top N =", N, "codon pool contributors."))
  removed_top_N_genes_correlation_to_mean_codon_usage <- ComputeWithoutTopNGenes(data = data_mRNA[object@meta.data$mRNAsInCommon, ],
                                                                                 codon_freq = codon_frequency_per_gene_table[ , object@meta.data$mRNAsInCommon],
                                                                                 mean_codon_usage = object@assays$MeanCodonUsage,
                                                                                 top_N_codon_pool_contributors = top_N_codon_pool_contributors_per_condition)

  correl_no_topN <- CodonPoolDiverstity(labels = colnames(object@assays$mRNA),
                                        codon_pool_contribution = codon_pool_contribution_of_top_N_genes,
                                        correlation_to_mean = removed_top_N_genes_correlation_to_mean_codon_usage)

  message("7. Updating the object.")
  metadata <- list(top_N_codon_pool_contributors_per_condition,
                   # codon_pool_diversity_v_correlation_to_mean_codon_usage, TO BE DIRECTLY ADDED IN THE FUNCTION
                   # removed_top_N_codon_pool_diversity_v_correlation_to_mean_codon_usage, TO BE DIRECTLY ADDED IN THE FUNCTION
                   correl_topN,
                   correl_no_topN)
  metadata_ids <- list("TopNCodonPoolContributorsPerCondition",
                       # "CodonPoolDiversity_vs_CorrelationToMeanCodonUsage", TO BE DIRECTLY ADDED IN THE FUNCTION
                       # "RemovedTopN_CodonPoolDiversity_vs_CorrelationToMeanCodonUsage", TO BE DIRECTLY ADDED IN THE FUNCTION
                       "CorrelationTopN",
                       "CorrelationRemovedTopN")
  # object <- UpdateTEscanR_Object(object = object,
  #                                counts = codon_usage_across_conditions,
  #                                assay = "MeanCodonUsage",
  #                                meta.data = metadata,
  #                                meta.data.ids = metadata_ids,
  #                                overwrite.assay = overwrite.assay,
  #                                overwrite.metadata = overwrite.metadata)

  return(object)

}
