#' @importFrom tidyr separate
#' @importFrom ggplot2 ggplot aes theme_classic geom_jitter labs theme element_text scale_color_manual geom_bar facet_wrap
utils::globalVariables(c("target", "ymax", "ymin", "labelPosition", "head"))
NULL

GetOutputName <- function(out_name,
                          out_directory,
                          save_format){

  if (!is.null(out_name) & !is.null(out_directory)){
    output_file <- paste(out_directory, out_name, sep = "/")

  } else if(!is.null(out_name) & is.null(out_directory)){
    message("No output directory has not been specified in `out_directory`, the plot will be save in the current working directory.")
    output_file <- paste(getwd(), out_name, sep = "/")

  } else if(is.null(out_name) & !is.null(out_directory)){
    message("No output file name has not been specified in `out_name`, the plot will be save as `distribution_plot`.")
    output_file <- paste(out_directory, "distribution_plot", sep = "/")

  } else{
    message("No output directory has not been specified in `out_directory`, the plot will be save in the current working directory.")
    message("No output file name has not been specified in `out_name`, the plot will be save as `distribution_plot`.")
    output_file <- paste(getwd(),  "distribution_plot", sep = "/")
  }

  if (!save_format %in% output_file){
    output_file <- paste(output_file, save_format, sep = ".")
  }
  message(paste("The generated plot will be save in:", output_file))

  return (output_file)
}

DrawJitterPlot <- function(target,
                           data,
                           x_axis_col,
                           y_axis_col,
                           arg1,
                           arg2,
                           color_palette,
                           add_titles,
                           show_legend){

  if (isFALSE(target)){
    color_factor <- ifelse(length(data[[arg1]]) == 1, arg2, arg1)
    plot <- ggplot(data = data, mapping = aes(x = .data[[x_axis_col]], y = .data[[y_axis_col]], color = .data[[color_factor]]))
  } else {
    plot <- ggplot(data = data, mapping = aes(x = .data[[x_axis_col]], y = .data[[y_axis_col]], color = target))
  }

  if(!is.null(color_palette)){
    plot <- plot + theme_classic() + geom_jitter(size = 0.5) + ggplot2::scale_color_manual(values = color_palette)
  } else {
    plot <- plot + theme_classic() + geom_jitter(size = 0.5)
  }

  if(isTRUE(add_titles)){
    plot <- plot +
      labs(title = paste(x_axis_col, "usage across", arg2), x = x_axis_col, y = paste("Proportion of total", x_axis_col, "usage")) +
      theme(axis.text.x = element_text(angle = 90),
            plot.title = element_text(hjust = 0.5, size = 20))
  }

  if(isTRUE(show_legend))  plot <- plot + theme(legend.position = "bottom")

  return(plot)
}

DrawBarPlot <- function(target,
                        data,
                        x_axis_col,
                        y_axis_col,
                        arg1,
                        arg2,
                        color_palette,
                        add_titles,
                        show_legend,
                        panels){

  if (isFALSE(target)){
    color_factor <- ifelse(length(unique(data[[arg1]])) == 1, arg2, arg1)
    plot <- ggplot(data = data, mapping = aes(x = .data[[x_axis_col]], y = .data[[y_axis_col]], fill = .data[[color_factor]]))
    if(isTRUE(panels)) plot <- plot + ggplot2::facet_wrap(~.data[[arg1]])

  } else {
    plot <- ggplot(data = data, mapping = aes(x = .data[[x_axis_col]], y = .data[[y_axis_col]], fill = target))
    if(isTRUE(panels)) plot <- plot + ggplot2::facet_wrap(~target)
  }

  plot <- plot + ggplot2::geom_bar(stat = "identity", position = "dodge") + theme_classic() # ENABLE TO CUSTOMIZE THE POSITION OF THE BARS !

  if(!is.null(color_palette)) plot <- plot + ggplot2::scale_fill_manual(values = color_palette)

  if(isTRUE(add_titles)){
    plot <- plot +
      labs(title = paste(x_axis_col, "usage across", arg2),
           x = x_axis_col,
           y = paste("Count of", x_axis_col, "usage")) +
      theme(axis.text.x = element_text(angle = 90),
            plot.title = element_text(hjust = 0.5, size = 20))
  }

  if(isTRUE(show_legend)) plot <- plot + theme(legend.position = "bottom")


  return(plot)
}

#' Distribution plots of codon/anticodon usage or amino acids demand/supply
#'
#' @param data Long format dataset containing: (i) codon/anticodon/amino acids, (ii) conditions, and (iii) usage counts.
#' @param plot String variable to specify the plot geom to display.
#' @param panels Optional variable to include a vector containing the mean for each codon in included in the `data` input.
#' @param x_axis_col String variable to identify the column that will be used as x-axis.
#' @param y_axis_col String variable to identify the column that will be used as y-axis.
#' @param condition_col String variable to identify the column that will be used to group the different conditions.
#' @param separator Optional string parameter to specify the symbol use to separate (if applicable) different arguments in the `condition_col` variable.
#' @param arg1 Optional string parameter to name the 1st argument of the `condition_col` variable.
#' @param arg2 Optional string parameter to name the 2nd argument of the `condition_col` variable.
#' @param color_palette Optional vector parameter containing color codes to be used in the plot.
#' @param targeted_arg Optional vector parameter containing the bigger clusters to define.
#' @param save_format Optional string parameter specifying the format to store the plot in.
#' @param out_name Optional string parameter specifying the output name (if `save_format` specified).
#' @param out_directory Optional string parameter specifying the output directory name (if `save_format` specified).
#' @param show_legend Boolean parameter to include or not the legend in the plot.
#' @param add_titles Boolean parameter to include or not the titles (including in both axis) in the plot.
#'
#' @return Plot.
#' @export
#'

tTE_DistributionPlot <- function(data,
                                 plot = "jitter",
                                 panels = FALSE,
                                 x_axis_col,
                                 y_axis_col,
                                 condition_col,
                                 separator = NULL,
                                 arg1 = NULL,
                                 arg2 = NULL,
                                 color_palette = NULL,
                                 targeted_arg = NULL,
                                 save_format = NULL,
                                 out_name = NULL,
                                 out_directory = NULL,
                                 show_legend = TRUE,
                                 add_titles = TRUE) {

  CheckDataInLongFormat(data) # Check that the data given is in long format.
  ExistColumnInData(data = data, column_names = c(x_axis_col, y_axis_col, condition_col)) # Check that the names given correspond to column names.

  if(is.null(separator)){
    message("The ", condition_col, " has just one argument.\n",
            "If several arguments are present, please specify a `separator` input parameter.")
    arg1 <- condition_col
    arg2 <- condition_col
  } else{
    if(is.null(arg1)) arg1 <- "argument1"
    if(is.null(arg2)) arg2 <- "argument2"

    # Split the condition_col based on the separator
    data <- data %>%
      separate({{ condition_col }}, into = c(arg1, arg2), sep = separator)
  }

  if(!is.null(targeted_arg)){
    data$target <- "Other"
    missing_target <- list()
    total_missing <- 0
    for (i in 1:length(targeted_arg)){
      index <- which(data[[arg1]] == targeted_arg[i])

      if (length(index) == 0) {
        missing_target <- append(missing_target, targeted_arg[i])
        total_missing <- total_missing + 1
      } else{
        data$target[index] <- targeted_arg[i]
      }
    }

    if(total_missing != 0){
      if(total_missing == length(targeted_arg)){
        for (i in 1:length(targeted_arg)){
          index <- which(data[[arg2]] == targeted_arg[i])
          if (length(index) == 0) {
            stop(paste("The argument", targeted_arg[i], "has not been found in the categories defined in the data."))
          } else{
            data$target[index] <- targeted_arg[i]
          }
        }
      } else {
        for (i in 1:length(missing_target)){
          message(paste("The argument", targeted_arg[i], "has not been found in the categories defined in the data."))
        }
        stop()
      }
    }

    if(!is.null(color_palette)){
      if(length(color_palette) != length(unique(data$target))){
        stop("The number of colors in `color_palette` does not correspond to the number of categories in `targeted_arg` plus an extra one (represents the non-targeted conditions).\n",
             paste("Number of colors needed:", length(unique(data$target))))
      }
    }

    target <- TRUE

  } else {
    if(!is.null(color_palette)){
      if(length(color_palette) != length(unique(data[[arg1]]))){
        stop("The number of colors in `color_palette` does not correspond to the number of categories in `arg1`.\n",
             paste("Number of colors needed:", length(unique(data[[arg1]]))))
      }
    }

    target <- FALSE
  }

  # Generate plot
  if (plot == "jitter"){
    plot <- DrawJitterPlot(target = target, data = data,
                           x_axis_col = x_axis_col, y_axis_col = y_axis_col,
                           arg1 = arg1, arg2 = arg2,
                           color_palette = color_palette, add_titles = add_titles, show_legend = show_legend)
  } else if (plot == "barplot"){
    plot <- DrawBarPlot(target = target, data = data,
                        x_axis_col = x_axis_col, y_axis_col = y_axis_col,
                        arg1 = arg1, arg2 = arg2,
                        color_palette = color_palette, add_titles = add_titles, show_legend = show_legend,
                        panels = panels)
  }

  # Save the ggplot
  if(!is.null(save_format)){
    if(save_format == "png" || save_format == "pdf"){
      output_file <- GetOutputName(out_name = out_name, out_directory = out_directory, save_format = save_format)
      ggplot2::ggsave(output_file, plot = plot, width = 8, height = 6)
    } else {
      message("The input `save_format` is not recognized.\n",
              "Please, specify png or pdf.")
      return(plot)
    }
  } else {
    return(plot)
  }

}

#' Distribution plots of codon/anticodon usage or amino acids demand/supply compared to the mean
#'
#' @param data Vector containing: codon/anticodon/amino acids usage for a specific condition.
#' @param mean Vector containing the mean values of the codon/anticodon/amino acids included in `data`.
#' @param x_axis_col String variable to identify the column that will be used as x-axis.
#' @param y_axis_col String variable to identify the column that will be used as y-axis.
#' @param show_difference Boolean variable to indicate if the difference between the mean and the targeted values should be displayed.
#' @param color_palette Optional vector parameter containing color codes to be used in the plot: (i) mean, (ii) target value, (iii) difference bar (optional).
#' @param save_format Optional string parameter specifying the format to store the plot in.
#' @param out_name Optional string parameter specifying the output name (if `save_format` specified).
#' @param out_directory Optional string parameter specifying the output directory name (if `save_format` specified).
#' @param show_legend Boolean parameter to include or not the legend in the plot.
#' @param add_titles Boolean parameter to include or not the titles (including in both axis) in the plot.
#'
#' @return Plot.
#' @export
#'

tTE_CompareTargetToMean <- function(data,
                                    mean,
                                    x_axis_col,
                                    y_axis_col,
                                    show_difference = TRUE,
                                    color_palette = NULL,
                                    save_format = NULL,
                                    out_name = NULL,
                                    out_directory = NULL,
                                    show_legend = TRUE,
                                    add_titles = TRUE){

  ExistColumnInData(data = mean, column_names = c(x_axis_col, y_axis_col)) # Check that the names given correspond to column names.
  mean$target <- data[,2]

  if(is.null(color_palette)){
    plot <- ggplot(data = mean, mapping = aes(x = .data[[x_axis_col]], y = .data[[y_axis_col]])) +
      ggplot2::geom_bar(stat = "identity", fill = "#CCCCCC") +
      ggplot2::geom_point(mapping = aes(y = target), color = "#B10DA1") + theme_classic()
    if(isTRUE(show_difference)){
      plot <- plot + ggplot2::geom_segment(mapping = aes(xend = .data[[x_axis_col]], yend = target), color = "blue")
    }

  } else if(!is.null(color_palette) && length(color_palette) == 3){
    plot <- ggplot(data = mean, mapping = aes(x = .data[[x_axis_col]], y = .data[[y_axis_col]])) +
      ggplot2::geom_bar(stat = "identity", fill = color_palette[0]) +
      ggplot2::geom_point(mapping = aes(y = target), color = color_palette[2]) + theme_classic()

    if(isTRUE(show_difference)){
      plot <- plot + ggplot2::geom_segment(mapping = aes(xend = .data[[x_axis_col]], yend = target), color = color_palette[3])
    }

  } else if(!is.null(color_palette) && length(color_palette) == 2){
    plot <- ggplot(data = mean, mapping = aes(x = .data[[x_axis_col]], y = .data[[y_axis_col]])) +
      ggplot2::geom_bar(stat = "identity", fill = color_palette[1]) +
      ggplot2::geom_point(mapping = aes(y = target), color = color_palette[2]) + theme_classic()

    if(isTRUE(show_difference)){
      message("The difference can not be plotted as just two color values have been indicated in the `color_palette` input parameter.")
    }
  } else if(!is.null(color_palette) && length(color_palette) < 2){
    stop("Please, revise the color values given in the `color_palette` input parameter.\n",
         "At least two colors need to be input or select NULL for using default colors.")
  }

  if(isTRUE(add_titles)){
    plot <- plot +
      labs(title = "Comparison to the mean",
           x = x_axis_col,
           y = y_axis_col) +
      theme(axis.text.x = element_text(angle = 90),
            plot.title = element_text(hjust = 0.5, size = 20))
  }

  if(isTRUE(show_legend)) plot <- plot + theme(legend.position = "bottom")

  # Save the ggplot
  if(!is.null(save_format)){
    if(save_format == "png" || save_format == "pdf"){
      output_file <- GetOutputName(out_name = out_name, out_directory = out_directory, save_format = save_format)
      ggplot2::ggsave(output_file, plot = plot, width = 8, height = 6)
    } else {
      message("The input `save_format` is not recognized.\n",
              "Please, specify png or pdf.")
      return(plot)
    }
  } else {
    return(plot)
  }

}

DrawDonutPlot <- function(data,
                          var_numerical,
                          var_categorical,
                          color_palette,
                          show_legend){

  # Compute percentages
  total <- sum(data[[var_numerical]], na.rm = TRUE)
  if(total == 0) stop("Error: Sum of var_numerical is zero, cannot compute fractions.")
  data$fraction <- data[[var_numerical]] / total

  # Compute the cumulative percentages
  data$ymax <- cumsum(data$fraction)
  data$ymin <- c(0, head(data$ymax, -1))

  # Compute the label position
  data$labelPosition <- (data$ymax + data$ymin) / 2
  if (isFALSE(show_legend)){
    data$label <- paste0(data[[var_categorical]], ": ", round(data[[var_numerical]], 3))
  } else{
    data$label <- paste0(round(data[[var_numerical]], 3))
  }

  # I NEED TO ADJUST THE SIZES AND ALSO ACCOUNT FOR THE REST OF POSSIBLE SITUATIONS
  if (length(unique(data[[var_categorical]])) > 11 && length(unique(data[[var_categorical]] < 21))){
    circle_max <- 4
    circle_min <- 3
    label_position <- 7
    label_size <- 3
  } else if (length(unique(data[[var_categorical]])) > 22 && length(unique(data[[var_categorical]] < 32))){
    circle_max <- 5
    circle_min <- 4
    label_position <- 9
    label_size <- 2
  }

  plot <- ggplot(data, aes(ymax = ymax, ymin = ymin, xmax = circle_max, xmin = circle_min, fill = .data[[var_categorical]])) +
    ggplot2::geom_rect() +
    ggplot2::geom_label(x = label_position, aes(y = labelPosition, label = label), size = label_size) +
    ggplot2::coord_polar(theta = "y") +
    ggplot2::xlim(c(-1, label_position)) +
    ggplot2::theme_void()

  if (!is.null(color_palette) && length(color_palette) == length(unique(data[[var_categorical]]))){
    plot <- plot + ggplot2::scale_color_manual(values = color_palette)
  }

  if (isFALSE(show_legend)){
    plot <- plot + ggplot2::theme(legend.position = "none")
  } else {
    plot <- plot + ggplot2::theme(legend.position = "bottom")
  }

  return(plot)
}

# I NEED TO SOLVE THE PROBLEMS WITH THE ggradar PACKAGE REQUIRE TO DRAW TO PLOT !!!
RadarPlot <- function(data,
                      var_numerical,
                      var_categorical,
                      color_palette,
                      show_legend){

  if (isFALSE(show_legend)){
    plot <- ggradar(data,
                    background.circle.color = "white",
                    gridline.min.linetype = 1,
                    gridline.mid.linetype = 1,
                    gridline.max.linetype = 1,
                    legend_position = "none")
  } else {
    plot <- ggradar(data,
                    background.circle.color = "white",
                    gridline.min.linetype = 1,
                    gridline.mid.linetype = 1,
                    gridline.max.linetype = 1,
                    legend_position = "bottom")
  }

  return(plot)
}

#' Proportion plots of codon/anticodon usage or amino acids demand/supply compared to the mean
#'
#' @param data Vector containing: codon/anticodon/amino acids usage for a specific condition.
#' @param var_numerical String variable to identify the column that contains the numerical data.
#' @param var_categorical String variable to identify the column that contains the categorical data.
#' @param plot String variable to specify the plot geom to display.
#' @param color_palette Optional vector parameter containing color codes to be used in the plot: (i) mean, (ii) target value, (iii) difference bar (optional).
#' @param save_format Optional string parameter specifying the format to store the plot in.
#' @param out_name Optional string parameter specifying the output name (if `save_format` specified).
#' @param out_directory Optional string parameter specifying the output directory name (if `save_format` specified).
#' @param show_legend Boolean parameter to include or not the legend in the plot.
#' @param add_titles Boolean parameter to include or not the titles (including in both axis) in the plot.
#'
#' @return Plot.
#' @export
#'

tTE_ProportionPlot <- function(data,
                               var_numerical,
                               var_categorical,
                               plot= "radar",
                               color_palette = NULL,
                               save_format = NULL,
                               out_name = NULL,
                               out_directory = NULL,
                               show_legend = TRUE,
                               add_titles = TRUE){

  # Check column names in data
  if(!is.numeric(data[[var_numerical]])) {
    stop(paste("Error: Column", var_numerical, "is not numeric."))
  }

  if (plot == "donut"){
    plot <- DrawDonutPlot(data = data,
                          var_numerical = var_numerical,
                          var_categorical = var_categorical,
                          color_palette = color_palette,
                          show_legend = show_legend)

  } else if (plot == "radar"){
    plot <- DrawRadarPlot(data = data,
                          var_numerical = var_numerical,
                          var_categorical = var_categorical,
                          color_palette = color_palette,
                          show_legend = show_legend)
  }

  # Save the ggplot
  if(!is.null(save_format)){
    if(save_format == "png" || save_format == "pdf"){
      output_file <- GetOutputName(out_name = out_name, out_directory = out_directory, save_format = save_format)
      ggplot2::ggsave(output_file, plot = plot, width = 8, height = 6)
    } else {
      message("The input `save_format` is not recognized.\n",
              "Please, specify png or pdf.")
      return(plot)
    }
  } else {
    return(plot)
  }
}
