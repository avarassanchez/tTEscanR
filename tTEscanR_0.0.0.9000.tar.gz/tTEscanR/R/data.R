#' mRNA Expression Data
#'
#' This dataset contains mRNA expression levels for a sample of genes (symbol name) across various cell types.
#'
#' @name mRNA_data
#' @docType data
#' @usage data(mRNA_data)
#'
NULL

#' tRNA Expression Data
#'
#' This dataset contains tRNA expression levels for a sample of genes across various cell types.
#'
#' @name tRNA_data
#' @docType data
#' @usage data(tRNA_data)
#'
NULL
