GetOrCompute <- function(object, slot, section, subset = NULL, verbose, compute_fun) {

  ###
  # CALL: ShowPoolContribution()
  # DESCRIPTION: This function checks is the requested data already exists in the input object or if it needs to be computed.
  ###

  exists <- IsIn_tTEscanR_Object(object, slot, section, subset, compute_assay = TRUE, verbose = FALSE)
  if (isTRUE(exists)) {
    if (is.null(subset)) return(slot(object, slot)[[section]])
    return(slot(object, slot)[[section]][[subset]])
  }
  if (verbose) message(paste("- Computing missing component:", section, subset))
  return(compute_fun())
}

ComputeIndividualGeneCorrelation <- function(codon_usage, mean_codon_usage, corr_method){

  ###
  # CALL: ShowPoolContribution()
  # DESCRIPTION: Identification of outliers: calculate correlation of each condition's codon usage to the mean codon usage across conditions.
  # This function takes as input the size corrected codon usage matrix and the mean codon usage.
  # It correlates each individual codon usage value with the mean codon usage (reference).
  ###

  correlation_vec <- stats::cor(mean_codon_usage$mean_usage_across_conditions, y = as.matrix(codon_usage), method = corr_method) # Vectorized correlation
  correlation_to_mean_codon_usage <- as.numeric(correlation_vec)
  names(correlation_to_mean_codon_usage) <- colnames(codon_usage)

  return(correlation_to_mean_codon_usage) # Returns a matrix that stores how similar the codon usage in a particular condition is to the mean codon usage across all conditions
}

AnalizeTopGeneImpact <- function(data, codon_freq, pool_contribution, mean_codon_usage, N, corr_method){

  # Identifying top N contributors based on the pool contribution
  top_contributors <- apply(pool_contribution, 2, function(x) {
    top_values <- sort(x, decreasing = TRUE)[1:N]
    return(list(sum = sum(top_values), names = names(top_values)))
  })

  sums <- sapply(top_contributors, `[[`, "sum")
  top_N_names <- do.call(cbind, lapply(top_contributors, `[[`, "names"))
  colnames(top_N_names) <- colnames(data)
  rownames(top_N_names) <- paste("top", seq_len(N), "gene", sep = "") # Restored old naming

  # Calculating correlation without top N genes
  data_copy <- as.matrix(data)
  for (i in seq_len(ncol(data_copy))) {
    data_copy[top_N_names[, i], i] <- 0
  }

  removed_top_N_genes_usage <- as.matrix(codon_freq) %*% data_copy
  removed_top_N_genes_usage <- t(t(removed_top_N_genes_usage) / colSums(removed_top_N_genes_usage))

  corr_no_top <- ComputeIndividualGeneCorrelation(codon_usage = removed_top_N_genes_usage, mean_codon_usage = mean_codon_usage, corr_method = corr_method)
  impact_summary <- tibble::tibble(condition = colnames(data), sum_top_contribution = sums, codon_diversity = 1 - sums, correlation = corr_no_top)

  return(list(summary = impact_summary, top_contributors = top_N_names, removed_contr = removed_top_N_genes_usage))
}
