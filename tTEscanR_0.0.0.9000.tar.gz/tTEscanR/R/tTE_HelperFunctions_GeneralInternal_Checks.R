CheckCodonFreqTable <- function(data, species, verbose = TRUE){

  ###
  # CALL: ConsistencyWithCodonFreq()
  # DESCRIPTION: This function checks the codon frequency per gene table needed to compute the codon usage.
  # If no user-defined codon frequency table is given, it loads (if enabled) the codon frequency matrix from the tTEscanR memory.
  ###

  if (is.null(data)){ # No user-defined codon frequency table has been given
    if (is.null(species)) stop("No 'codon_freq' provided and no 'species' specified.\n", "Specify 'hg38' for human or 'mm39' for mouse default data.")
    return(SelectDefaultData(species = species)) # Extract from the tTEscanR memory the default codon frequency table
  }

  # A user-defined codon-frequency table has been given
  CheckDataFrame(data = data, required_names = TRUE) # Check that the format of the table is suitable
  actual_codons <- rownames(data)

  return(data) # Returns the codon frequency per gene table
}

CheckDataFrame <- function(data, required_names = TRUE){

  ###
  # CALL: CheckCodonFreqTable()
  # DESCRIPTION: This function evaluates the format of the input data. There is no return value, the execution will stop upon an error.
  ###

  if (is.null(data)) stop("The dataset is empty or could not be found.") # Control - in case the data object is empty
  dims <- dim(data)

  if (is.null(dims) || dims[1] < 2 || dims[2] < 2){ # We use at least 2 columns and 2 rows to define a table - evaluate that it is not empty
    row_val <- ifelse(is.null(dims), 0, dims[1])
    col_val <- ifelse(is.null(dims), 0, dims[2])
    stop(sprintf("Incorrect dimensions. Expected at least 2x2. Found: %d x %d", row_val, col_val))
  }

  if (required_names){ # The required_names parameter is used to specify if the data needs to contain row and column names
    row_names <- rownames(data)
    col_names <- colnames(data)
    if (is.null(row_names) || is.null(col_names)) stop("Dataset labels missing. Both rownames and colnames are required.")
    if (any(row_names == "", na.rm = TRUE) || any(col_names == "", na.rm = TRUE)) stop("Dataset labels are incomplete. Empty strings detected in rownames or colnames.")
  }
  return(invisible(NULL))
}

CheckGeneAnnotation <- function(vector1, vector2, verbose = TRUE){

  ###
  # CALL: ConsistencyWithCodonFreq()
  # DESCRIPTION: This function compares the gene annotation of two vectors to ensure consistency.
  ###

  # Check in which format each vector of genes is
  format1 <- IsEnsemblID(vector1)
  format2 <- IsEnsemblID(vector2)

  if (format1 != format2) stop("Annotation mismatch detected!\n", "- Codon frequency table: ", format1, "\n", "- mRNA data: ", format2, ".\n", "Please ensure both datasets use the same gene naming convention.")
  if (verbose) message("Both vectors are in the same format: ", format1, ".")
}
