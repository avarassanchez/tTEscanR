#' @importFrom methods setClass new validObject
NULL

#' The tTEscanR Class
#' @description
#' The **tTEscanR** object is dynamically updated to store \code{assays} and \code{meta.data} at each analysis step.
#' Ensures efficient tracking and organization of inputs and outputs throughout the pipeline.
#' In order to ensure robustness throughout the pipeline, specific ids have been assigned and should be respected by the user.
#'
#' @slot assays A list of assays.
#' @slot meta.data A list of meta-information associated with the assays.
#'
#' @name tTEscanR_Object-class
#' @rdname tTEscanR_Object-class
#' @exportClass tTEscanR_Object

setClass(Class = 'tTEscanR_Object', slots = c(assays = 'list', meta.data = 'list'))

setValidity("tTEscanR_Object", function(object) {

  # The setValidity function is called by the new() function used to generate a tTEscanR_Object
  errors <- character() # Empty vector to store any validation errors

  # Set the names of the assays that can be included in a tTEscanR_Object
  valid_assay_ids <- c("mRNA", "tRNA", "CodonUsage", "AnticodonUsage", "AADemand", "AASupply",
                       "SizeCorrected_mRNA", "SizeCorrectedCodonUsage", "SizeCorrectedAADemand",
                       "SizeCorrected_tRNA", "SizeCorrectedAnticodonUsage", "SizeCorrectedAASupply")

  if (length(object@assays) > 0) { # Check if the assay list is not empty

    assay_names <- names(object@assays)

    if (is.null(assay_names)) { # Check if all the elements of the list are named
      errors <- c(errors, "The 'assays' list must have named elements.")
    } else {

      invalid_names <- setdiff(assay_names, valid_assay_ids)
      if (length(invalid_names) > 0) { # Check the validity of the names
        error_msg <- paste("Invalid 'assay' names detected:", paste(invalid_names, collapse = ", "),
                           "\n Valid names are:", paste(valid_assay_ids, collapse = ", "))
        errors <- c(errors, error_msg)
      }

      duplicated_names <- duplicated(assay_names)
      if (any(duplicated_names)) { # Check for duplicated names
        error_msg <- paste("Duplicated 'assay' names detected:",
                           paste(unique(assay_names[duplicated_names]), collapse = ","))
        errors <- c(errors, error_msg)
      }
    }
  }

  if (length(errors) == 0) return(TRUE) else return(errors)
})


#' Create a tTEscanR Object
#' @description
#' This function initializes a \code{tTEscanR_Object}, a structured container designed to hold translational efficiency-related data.
#' The object consists of two main components; \code{assays}, which stores data matrices (e.g. expression, codon usage),
#' and \code{meta.data}, which stores associated information and additional intermediate calculations.
#' A \code{tTEscanR_Object} can be created using a single dataset, or initialized with a list of datasets provided at once.
#' Additional assays and metadata layers can be appended later using the \code{\link{Update_tTEscanR_Object}} function.
#'
#' @details
#' In order to ensure robustness throughout the pipeline **specific ids** have been assigned and should be respected by the user.
#' **\code{assays} slot:**
#' - mRNA and tRNA count matrices as \code{"mRNA"} and \code{"tRNA"}
#' - Codon and anticodon usage count matrices as \code{"CodonUsage"} and \code{"AnticodonUsage"}
#' - Amino acid demand and supply count matrices as \code{"AADemand"} and \code{"AASupply"}
#' - Size corrected count matrices contain the prefix \code{"SizeCorrected"} added to the raw count matrices names (e.g. \code{"SizeCorrected_mRNA} or \code{"SizeCorrectedCodonUsage})
#' **\code{meta.data} slot:**
#' - Table with the conditions of the mRNA and tRNA data as \code{"ConditionsLabels"}
#' - Active correction factor to use when running differential expression analyses as \code{"CorrectionFactor"}
#' - Optional; Identifier \code{DataMetadataIndex} to indicate the column in \code{"ConditionsLabels"} that contains the labels of the conditions of the \code{assay}.
#'
#' @param counts A count \code{matrix} (or \code{list} of matrices) that will be stored in the \code{assays} slot.
#' @param assay Optional; a \code{character} string (or \code{list} of characters) to identify the \code{counts}. Required if \code{counts} is not a named \code{list}.
#' @param meta.data Optional; a variable (or \code{list} of variables) with additional information that will be stored in \code{meta.data} slot.
#' @param meta.data.ids Optional; a \code{character} string (or \code{list} with the labels) to identify the \code{meta.data}. Required if \code{meta.data} is not a named \code{list}.
#' @param verbose Logical; if \code{TRUE}, displays information messages. Defaults to \code{TRUE}.
#'
#' @return A \code{tTEscanR_Object}.
#' @export
#'
#' @examples
#' data(subset_mRNA_data, subset_tRNA_data, metadata)
#' tTEscanR_obj <- Create_tTEscanR_Object(counts = list(mRNA = subset_mRNA_data,
#'                                                      tRNA = subset_tRNA_data),
#'                                        meta.data = metadata, meta.data.ids = "ConditionsLabels")

Create_tTEscanR_Object <- function(counts, assay = NULL, meta.data = NULL, meta.data.ids = NULL, verbose = TRUE){

  ###
  # CALL: User
  # DESCRIPTION: This function creates a tTEscanR object.
  # Using this function the metadata elements (if dealing with lists) are added independently.
  ###

  message("--- Creation of a tTEscanR Object ---", "\n1 . Initial assessment and addition of the input data.")
  if (verbose) message("- Adding the 'counts' to the tTEscanR object.") # Mandatory
  assay.list <- DefineNewData(data = counts, id = assay, mode = "fix", verbose = verbose, action_update = FALSE)

  metadata.list <- list()
  if (!is.null(meta.data)){
    if (verbose) message("- Adding the 'metadata' to the tTEscanR object.")
    metadata.list <- DefineNewData(data = meta.data, id = meta.data.ids, mode = "flexible", verbose = verbose)
  }

  object <- suppressWarnings(expr = new(Class = 'tTEscanR_Object', assays = assay.list, meta.data = metadata.list)) # Generate the object

  message("1 . COMPLETED\n", "--- The tTEscanR Object has been successfully created ---")
  return(object)
}
