GroupAA <- function(data, codons, genetic_code){

  ###
  # CALL: ComputeAAUsage()
  # DESCRIPTION: This function takes a codon usage or anticodon usage and groups the features into amino acids.
  ###

  aa_map <- stats::setNames(final_matrix_genetic_code[[genetic_code]], final_matrix_genetic_code$Codon)
  AAextracted <- unname(aa_map[codons])

  if (length(AAextracted) == 0 || all(is.na(AAextracted))) stop("No amino acids could be retrieved.")
  if (nrow(data) != length(AAextracted)) stop(sprintf("Dimension mismatch: 'data' has %d rows, but %d amino acids were extracted.", nrow(data), length(AAextracted)))

  # Vectorized aggregation
  AAmatrix <- rowsum(as.matrix(data), group = AAextracted) # Compute sum of rows for each amino acid
  AAmatrix <- AAmatrix[order(rownames(AAmatrix)), , drop = FALSE] # Sort the amino acids alphabetically

  CheckDataFrame(data = AAmatrix) # Ensure that the generated matrix is valid
  return(AAmatrix) # Return amino acid by condition matrix
}

RetrieveAAUsageData <- function(object, data_section, data_function, genetic_code){

  ###
  # CALL: ComputeAAUsage()
  # DESCRIPTION: This function runs the intermediate checks for each of the sections considered in ComputeAAUsage().
  ###

  IsIn_tTEscanR_Object(object = object, slot = "assays", section = data_section, verbose = FALSE) # Check if the required assays are present in the tTEscanR object
  raw_data <- object@assays[[data_section]]
  CheckDataFrame(data = raw_data) # Check that the data is in a suitable format

  if (data_function == "sense") { # Extract AA from the codons - AADemand

    if (!genetic_code %in% colnames(final_matrix_genetic_code)) {
      valid_codes <- paste(colnames(final_matrix_genetic_code)[-1], collapse = ", ")
      stop(sprintf("Genetic code '%s' not found. Available codes are: %s", genetic_code, valid_codes))
    }

    aa_translations <- final_matrix_genetic_code[[genetic_code]] # Extract the amino acid translations for the selected code
    dynamic_sense_codons <- final_matrix_genetic_code$Codon[aa_translations != "*"] # Filter out the stop codons ("*") to get only the sense codons
    raw_data <- raw_data[rownames(raw_data) %in% dynamic_sense_codons, , drop = FALSE]

    target_codons <- rownames(raw_data)

  } else { # Extract AA from the anticodons
    target_codons <- as.character(Biostrings::reverseComplement(Biostrings::DNAStringSet(rownames(raw_data))))
  }

  return(list(data = raw_data, codons = target_codons)) # The output consists of list with the data, and the codon/anticodons
}
