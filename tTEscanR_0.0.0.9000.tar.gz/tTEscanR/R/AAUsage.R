#' Compute Amino Acid (AA) Demand or Supply
#' @description
#' This function calculates the amino acid (AA) demand and/or supply from a codon and/or anticodon usage matrices of a \code{tTEscanR_Object}.
#' It aggregates the contribution of their features based on the standard genetic code (mapping codons/anticodons to AA),
#' The resulting values reflect total usage (demand) or availability (supply) of each amino acid, depending on the input type.
#'
#' @param object A \code{tTEscanR_Object} containing codon and/or anticodon usage assays to be analyzed.
#' @param level Either \code{"demand"}, \code{"supply"} or \code{"both"} to indicate which analysis to perform.
#' @param genetic_code A \code{character} string to specify the genetic code to be used. Defaults to \code{"Standard"}.
#' @param overwrite_assay Logical; if \code{TRUE}, overwrites any existing assay in the \code{object}. Defaults to \code{FALSE}
#' @param verbose Logical; if \code{TRUE}, displays information messages. Defaults to \code{TRUE}
#'
#' @return An updated \code{tTEscanR_Object} containing a new layer of information in the \code{assays} slot representing the AA demand and/or supply.
#' @export
#'
#' @examples
#' data(subset_tRNA_data)
#' tTEscanR_obj <- Create_tTEscanR_Object(counts = subset_tRNA_data, assay = "tRNA")
#' tTEscanR_obj <- ComputeAnticodonUsage(object = tTEscanR_obj)
#' tTEscanR_obj <- ComputeAAUsage(object = tTEscanR_obj, level = "supply")

ComputeAAUsage <- function(object, level, genetic_code = "Standard", overwrite_assay = FALSE, verbose = TRUE){

  ###
  # CALL: User or Compute_tTE()
  # DESCRIPTION: This function computes separately or simultaneously the AA demand/supply of codon/anticodon usage matrices.
  ###

  if (level == "both") level_name <- "usage" else level_name <- level
  message(paste("\n--- Computation of the amino acid", level_name, " ---"), "\n1 . Checking the format of the input data.")
  if (!(inherits(object, 'tTEscanR_Object'))) stop("'object' must be a tTEscanR object.")
  if (is.null(level) || !level %in% names(assay_map_AA)) stop("Please specify a valid 'level' input parameter: demand, supply, both.")
  if (verbose) message("- The input consists of a proper tTEscanR object.\n", "- The 'level' has been porperly specified.")

  current_map <- assay_map_AA[[level]]
  n <- length(current_map$check_assays)
  results <- vector("list", n) # Create empty lists to store the outputs

  for (i in seq_len(n)) { # Iterates for the amount of assays that need to be retrieved
    results[[i]] <- RetrieveAAUsageData(object = object, data_section = current_map$check_assays[[i]], genetic_code = genetic_code,
                                        data_function = current_map$AAfunction[[i]]) # Checks if required assays are in the object
  }

  if (verbose) message("- The mRNA and/or tRNA data matrices have been properly loaded.")
  message("1 . COMPLETED\n", "2 . Pooling counts from each amino acid.")

  for(i in seq_along(results)){ # Iterate over each assay stored
    current_id <- current_map$assay_id[[i]]
    if (verbose) message(paste("- Performing the", current_id, "analysis.")) # Reports the name of the assay analyzed in each iteration
    AAmatrix <- GroupAA(data = results[[i]]$data, codons = results[[i]]$codons, genetic_code = genetic_code) # Group the codons/anticodons into AA
    object <- suppressMessages(Update_tTEscanR_Object(object = object, counts = AAmatrix, assay = current_id, overwrite_assay = overwrite_assay, verbose = FALSE))
  }
  message("2 . COMPLETED\n", paste("--- The amino acid", level_name, "has been successfully computed ---\n"))
  return(object) # The output tTEscanR object has been validated in Update_tTEscanR_Object()
}
