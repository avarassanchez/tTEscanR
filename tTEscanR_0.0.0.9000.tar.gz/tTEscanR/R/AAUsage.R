GroupAA <- function(data,
                    amino_acids_function){

  AAextracted <- as.vector(Biostrings::translate(amino_acids_function, no.init.codon = TRUE))
  AAunique <- sort(unique(AAextracted))

  AAmatrix <- matrix(data = 0, nrow = length(AAunique), ncol = length(colnames(data)))
  dimnames(AAmatrix) <- list(AAunique, colnames(data))

  for (i in 1:length(AAunique)) {
    indices <- which(AAextracted == AAunique[i])
    AAmatrix[i, ] <- Matrix::colSums(data[indices, , drop = FALSE])
  }

  return(AAmatrix)
}

#' Compute Amino Acid (AA) Demand or Supply
#'
#' @param object A \code{tTEscanR_Object} containing a codon or anticodon usage assay.
#' @param action A character string specifying "demand" or "supply".
#' @param overwrite.assay Logical; if TRUE, overwrites the assay (if already present in the \code{tTEscanR_Object}).
#' @param overwrite.metadata Logical; if TRUE, overwrites the metadata (if already present in the \code{tTEscanR_Object}).
#' @param verbose Logical; if TRUE, displays information messages.
#'
#' @return An updated \code{tTEscanR_Object} containing a new layer of information representing the AA demand or supply.
#' @export
#'
#' @examples
#' data(mRNA_data)
#' data(tRNA_data)
#' mRNA_data_translated <- TranslateGeneName(data_to_translate = mRNA_data,
#'                                           species = "hg38",
#'                                           position = "row",
#'                                           notation = "id")
#' tTEobj <- Create_tTEscanR_Object(counts = mRNA_data_translated, assay = "mRNA")
#' tTEobj <- Update_tTEscanR_Object(object = tTEobj, counts = tRNA_data, assay = "tRNA")
#' tTEobj <- ComputeCodonUsage(object = tTEobj,
#'                             codon_freq = NULL,
#'                             species = "hg38",
#'                             filter = "canonical",
#'                             reduce = 10000)
#' tTEobj <- ComputeAnticodonUsage(object = tTEobj)
#' tTEobj <- ComputeAAUsage(object = tTEobj, action = "demand")
#' tTEobj <- ComputeAAUsage(object = tTEobj, action = "supply")
#' tTEobj <- ComputeAAUsage(object = tTEobj, action = "both",
#'                          overwrite.assay = TRUE, overwrite.metadata = TRUE)

ComputeAAUsage <- function(object,
                           action,
                           overwrite.assay = FALSE,
                           overwrite.metadata = FALSE,
                           verbose = TRUE){

  if (verbose) message("1. Evaluating the input tTEscanR object.")
  if (!inherits(object, 'tTEscanR_Object')){
    stop("`object` must be a tTEscanR object.")
  }

  if (action == "demand"){
    IsIn_tTEscanR_Object(object = object, section = "CodonUsage", verbose = verbose)
    data <- object@assays$CodonUsage
    amino_acids_function <- Biostrings::DNAStringSet(sense_codons)
    assay_id <- "AADemand"

  } else if (action == "supply"){
    IsIn_tTEscanR_Object(object = object, section = "tRNA", verbose = verbose)
    ExistMetadata_tTEscanR_Object(object = object, section = "tRNAsAnticodons", verbose = verbose)
    data <- object@assays$tRNA
    amino_acids_function <- Biostrings::reverseComplement(Biostrings::DNAStringSet(object@meta.data$tRNAsAnticodons))
    assay_id <- "AASupply"

  } else if (action == "both"){
    IsIn_tTEscanR_Object(object = object, section = "CodonUsage", verbose = verbose)
    IsIn_tTEscanR_Object(object = object, section = "tRNA", verbose = verbose)
    ExistMetadata_tTEscanR_Object(object = object, section = "tRNAsAnticodons", verbose = verbose)

    data <- list(object@assays$CodonUsage, object@assays$tRNA)
    amino_acids_function <- list(Biostrings::DNAStringSet(sense_codons),
                                 Biostrings::reverseComplement(Biostrings::DNAStringSet(object@meta.data$tRNAsAnticodons)))
    assay_id <- c("AADemand", "AASupply")

  } else {
    stop("Please indicate a valid `action` parameter.\n",
         "Supported formats: demand, supply or both.")
  }

  if (action == "demand" || action == "supply"){
    if (verbose) message("2. Pooling counts from each amino acid.")
    CheckDataFrame(data = as.matrix(data))
    AAmatrix <- GroupAA(data = data, amino_acids_function = amino_acids_function)
    CheckDataFrame(data = AAmatrix)

    if (verbose) message("3. Updating the tTEscanR object.")
    object <- Update_tTEscanR_Object(object = object,
                                     counts = AAmatrix,
                                     assay = assay_id,
                                     overwrite.assay = overwrite.assay,
                                     overwrite.metadata = overwrite.metadata,
                                     verbose = verbose)
  } else {
    for(i in 1:length(data)){
      if (verbose){
        message(paste("Performing the", assay_id[[i]], "analysis."))
        message("2. Pooling counts from each amino acid.")
      }
      CheckDataFrame(data = as.matrix(data[[i]]))
      AAmatrix <- GroupAA(data = data[[i]], amino_acids_function = amino_acids_function[[i]])
      CheckDataFrame(data = AAmatrix)

      if (verbose) message("3. Updating the tTEscanR object.")
      object <- Update_tTEscanR_Object(object = object,
                                     counts = AAmatrix,
                                     assay = assay_id[[i]],
                                     overwrite.assay = overwrite.assay,
                                     overwrite.metadata = overwrite.metadata,
                                     verbose = verbose)
    }
  }

  return(object)
}
