#' Compute the Theoretical Translation Efficiency (tTE) score
#' @description
#' This function calculates the theoretical translation efficiency (tTE) score by integrating codon-anticodon usage and/or amino acid demand-supply across conditions.
#'
#' @param object A \code{tTEscanR_Object} containing a mRNA and a codon usage assay and/or a tRNA and an anticodon usage assay.
#' @param level Either \code{"codon"}, \code{"aa"} or \code{"both"} to indicate which analysis to perform.
#' @param genetic_code A \code{character} string to specify the genetic code to be used. Defaults to \code{"Standard"}.
#' @param corr_method A correlation method accepted by \code{\link{cor}}. Defaults to \code{"spearman"}.
#' @param compute_significance Logical; if \code{TRUE}, computes the statistical significance (p-value) of the tTE scores. Defaults to \code{TRUE}.
#' @param overwrite Logical; if \code{TRUE}, overwrites any existing tTE table in the \code{tTEscanR_Object}. Defaults to \code{FALSE}.
#' @param verbose Logical; if \code{TRUE}, displays information messages. Defaults to \code{TRUE}.
#'
#' @return An updated \code{tTEscanR_Object} containing a new layer of information representing the translation efficiency table for the matching conditions in the mRNA and tRNA data.
#' @export
#'
#' @examples
#' data(subset_mRNA_data, subset_tRNA_data, metadata)
#' tTEscanR_obj <- Create_tTEscanR_Object(counts = list(mRNA = subset_mRNA_data,
#'                                                      tRNA = subset_tRNA_data),
#'                                        meta.data = list(metadata, "tissue"),
#'                                        meta.data.ids = list("ConditionsLabels", "CorrectionFactor"))
#' tTEscanR_obj <- ComputeCodonUsage(object = tTEscanR_obj, species = "hg38",
#'                                   additional_metrics = FALSE, reduce = 10000)
#' tTEscanR_obj <- ComputeAnticodonUsage(object = tTEscanR_obj)
#' tTEscanR_obj <- Compute_tTE(object = tTEscanR_obj, level = "codon", compute_significance = FALSE)

Compute_tTE <- function(object, level = c("codon", "aa", "both"), genetic_code = "Standard", corr_method = c("spearman", "pearson", "kendall"), compute_significance = TRUE, overwrite = FALSE, verbose = TRUE){

  ###
  # CALL: User or Run_tTEscanR_pipeline()
  # DESCRIPTION: This function computes the theoretical translation efficiency (tTE) score by correlating codon-anticodon usage and/or amino acid demand-supply across conditions.
  ###

  message("\n--- Computation of the theoretical translation efficiency (tTE) ---", "\n1 . Checking the format of the input data.")
  if (!(inherits(object, 'tTEscanR_Object'))) stop("'object' must be a tTEscanR object.")
  if (verbose) message("- The input contains a proper tTEscanR object.")

  corr_method <- match.arg(corr_method)
  level <- match.arg(level)
  # if (!(corr_method %in% c("spearman", "pearson", "kendall"))) stop("Please specify a suitable `corr_method`.\n", "For further details check the cor() documentation.")

  target_levels <- if (level == "both") names(assay_map_TE) else level
  if (is.null(target_levels) || !all(target_levels %in% names(assay_map_TE))) stop("Please specify a valid 'level' input parameter: codon, aa, both.")

  # Evaluate that the required data assays are present in the object
  IsIn_tTEscanR_Object(object = object, slot = "assays", section = "tRNA", update_assay = FALSE, overwrite = FALSE, verbose = FALSE)

  # Evaluate that the required metadata variables are present in the object
  IsIn_tTEscanR_Object(object = object, slot = "meta.data", section = "ConditionsLabels", verbose = FALSE)
  IsIn_tTEscanR_Object(object = object, slot = "meta.data", section = "CorrectionFactor")
  meta <- object@meta.data$ConditionsLabels
  batch <- object@meta.data$CorrectionFactor
  if (!(batch %in% colnames(meta))) stop("The correction factor was not found in the metadata.")

  final_results <- list() # Empty list to store the results
  message("1 . COMPLETED\n", "2 . Computing the theoretical translation efficiency (tTE) analysis.")
  for (i in target_levels){
    if (verbose) message("\nProcessing level: ", i)

    config <- assay_map_TE[[i]]
    mRNA_raw <- object@assays[[config$mRNA]]
    tRNA_raw <- object@assays[[config$tRNA]]

    CheckDataFrame(data = mRNA_raw)
    CheckDataFrame(data = tRNA_raw)

    filter_results <- FilterMatrix(data_mRNA = mRNA_raw, data_tRNA = tRNA_raw, level = i, verbose = verbose) # Retain matching conditions in the mRNA and tRNA data

    if (verbose) message("- Filtering the metadata by the intersecting conditions.") # Filter the data and metadata based on the shared content
    filtered_data <- FilterByMetadata(data = filter_results$mRNA, metadata = meta, verbose = FALSE) # Evaluating the mRNA data

    if (verbose) message("- Size-correcting the data.") # The metadata is just retrieved once as it has been previously checked the consistency between mRNA and tRNA datasets
    mRNA_filtered <- ComputeSizeCorrection(data = filtered_data$data, metadata = filtered_data$metadata, batch = batch, verbose = FALSE)
    tRNA_filtered <- ComputeSizeCorrection(data = filter_results$tRNA, metadata = filtered_data$metadata, batch = batch, verbose = FALSE)

    # Compute the correlation between the mRNA and the tRNA data
    tTE_results_tibble <- ComputeCorrelation(data_mRNA = mRNA_filtered, data_tRNA = tRNA_filtered, corr_method = corr_method, verbose = verbose)

    if (isTRUE(compute_significance)){
      if (verbose) message("- Computing the statistical significance (this may take time)...")

      # Filter the tRNA expression data based on the shared conditions extracted above
      tRNA_exp_data <- object@assays$tRNA[, colnames(filter_results$mRNA), drop = FALSE] # Usage of tRNA expression matrix to increment the number of features considered in the shuffling analysis
      CheckDataFrame(data = tRNA_exp_data)
      tRNA_exp_data <- suppressMessages(ComputeSizeCorrection(data = tRNA_exp_data, metadata = filtered_data$metadata, batch = batch, verbose = FALSE))

      tTE_results_tibble <- ComputeStatisticalSignificance(level = i, tTE_scores = tTE_results_tibble, data_mRNA = mRNA_filtered, genetic_code = genetic_code,
                                                           data_tRNA = tRNA_filtered, tRNA_exp = tRNA_exp_data, corr_method = corr_method, verbose = verbose)
    }

    final_results[[config$id]] <- tTE_results_tibble
    if (verbose) message("\nCompleted the processing level: ", i)
  }

  message("\n2 . COMPLETED\n", "--- The theoretical translation efficiency (tTE) was properly computed ---\n")
  if (verbose) message("- Updating the tTEscanR object.")
  object <- Update_tTEscanR_Object(object = object, meta.data = final_results, meta.data.ids = names(final_results), overwrite_metadata = overwrite, verbose = FALSE)
  return(object) # The output tTEscanR object has been validated in Update_tTEscanR_Object()
}
