#' @importFrom stats as.dendrogram as.hclust dist hclust prcomp reorder
#' @importFrom rlang .data
#' @importFrom grDevices recordPlot
#'
utils::globalVariables(c("label", "log2_FC", "neg_log10_adjusted_p_value", "feature"))
NULL

ComputeDESeq2 <- function(data,
                          metadata,
                          formula,
                          targets = NULL,
                          reduce = 10000,
                          verbose = TRUE){

  if (any(data > .Machine$integer.max)){
    data <- data / reduce
    data <- round(data)

    if (verbose) message("- Some values of the input matrix exceed the maximum value accepted by R.\n",
                         paste("- The matrix has been divided by the factor, `reduce` = ", reduce,"."))
  }

  labels <- colnames(data)

  # Metadata for DESeq analysis
  # colData <- tibble::tibble(
  #   conditions = labels,
  #   factor_cond = sub(name_sep[1], name_sep[2], labels))

  colData <- tibble::as_tibble(metadata)

  if (!is.null(targets)){
    colData$class <- "other"
    contrast_vect <- c("class", "other")

    for (i in 1:nrow(targets)){
      colData$class[grep(targets[i,1], colData$cell.type)] <- targets[i,2]
      if (targets[i,2] %in% contrast_vect) contrast_vect <- contrast_vect else contrast_vect <- append(contrast_vect, targets[i,2])
    }

    print(table(colData$class))
    print(contrast_vect)
  }

  # Run DESeq2
  DESeq2_run <- DESeq2::DESeqDataSetFromMatrix(
    countData = data,
    colData = colData,
    design = formula)

  DESeq2_run <- DESeq2::DESeq(DESeq2_run)

  if (is.null(targets)) return(DESeq2_run) else return(list(DESeq2_run, contrast_vect))
}

#' Compute Size Correction to Account for Sequencing Depth
#'
#' @param data A matrix to analyze in the format of features (rows) per conditions (columns).
#' @param runDESeq2 Boolean variable to indicate if the differential expression analysis (DESeq2) needs to be executed
#' @param conditions A vector with the labels for each section of the conditions labels.
#' @param name_sep Specification of the notation separation used in the condition labels to run a DESeq2 analysis.
#' @param formula Design formula to use for the DESeq2 analysis. The name of the factors needs to be consistent with the column names of the \code{conditions}.
#' @param reduce Optional integer value to specify the factor to divide the values of the codon usage table if exceeded the maximum enabled by R.
#' @param verbose A boolean parameter to specify if the messages within the function should be display.
#'
#' @return Size corrected \code{data}.
#' @export
#'
#' @examples
#' data(mRNA_data)
#' size_corrected_mRNA_data <- ComputeSizeCorrection(data = mRNA_data,
#'                                                   runDESeq2 = TRUE,
#'                                                   conditions = c("tissue", "cell.type"),
#'                                                   name_sep = "-",
#'                                                   formula = ~ tissue)

ComputeSizeCorrection <- function(data,
                                  runDESeq2 = FALSE,
                                  conditions,
                                  formula,
                                  name_sep,
                                  reduce = 10000,
                                  verbose = TRUE){

  if (runDESeq2 == TRUE){
    metadata <- data.frame(label = colnames(data), stringsAsFactors = FALSE)
    metadata <- tidyr::separate(metadata, label, into = conditions, sep = name_sep)
    metadata$conditions <- colnames(data)
    CheckDataFrame(metadata)

    DESeq2_run <- ComputeDESeq2(data = data, metadata = metadata, formula = formula, reduce = reduce, verbose = verbose)
  } else {
    DESeq2_run <- data
  }

  size_corrected_output_matrix <- DESeq2::counts(DESeq2_run, normalized = TRUE)

  return(size_corrected_output_matrix)
}

# ComputeVarianceStabilization <- function(DESeq2_run){
#
#   vst <- DESeq2::varianceStabilizingTransformation(DESeq2_run)
#   return(vst)
# }

ProduceHeatmapDiffExp <- function(data){

  # Compute Euclidean distances
  Euc_Dists <- dist(t(data))

  # Sort nodes in hierarchical clustering
  sort_hclust <- function(...) as.hclust(dendsort::dendsort(as.dendrogram(...)))
  mat_cluster_names <- sort_hclust(hclust(Euc_Dists))

  # Control the size of the labels in the heatmap
  if (length(mat_cluster_names$labels) <= 30){
    fontsize <- 10
  } else if (length(mat_cluster_names$labels) <= 40){
    fontsize <- 7
  } else {
    fontsize <- 2
  }

  # Produce heatmap that has been hierarchically clustered
  Dist_heatmap <- pheatmap::pheatmap(Euc_Dists, cluster_cols = mat_cluster_names, cluster_rows = mat_cluster_names, color = viridis::inferno(1000),
                                     border_color = NA, labels_col = mat_cluster_names$labels, labels_row = mat_cluster_names$labels,
                                     fontsize_row = fontsize, fontsize_col = fontsize)
  return(Dist_heatmap)

}

ProduceElbowPlot <- function(data,
                             variance){

  elbow_tibble <- tibble::tibble(
    PC = 1:length(data$sdev),
    variance_explained = variance)

  elbow_plot <- ggplot2::ggplot(data = elbow_tibble) +
    ggplot2::theme_classic() +
    ggplot2::geom_bar(mapping = ggplot2::aes(x = reorder(.data$PC, -.data$variance_explained),
                                             y = .data$variance_explained), stat = "identity") +
    ggplot2::labs(title = "Percentage of variance explained per PC",
                  x = "PC",
                  y = "% variance explained") +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90))

  return(elbow_plot)
}

ProducePCAPlot <- function(data,
                           variance,
                           metadata,
                           numPC,
                           color_factor,
                           labels){

  outputs_PCA <- list()

  PC_columns <- lapply(1:numPC, function(i) data$x[, i])
  names(PC_columns) <- paste0("PC_", 1:numPC)

  # PCA_plot_tibble <- tibble::tibble(
  #   factor = sub(name_sep[1], name_sep[2], rownames(data$x)),
  #   conditions = rownames(data$x),
  #   !!!PC_columns
  # )

  PCA_plot_tibble <- tibble::tibble(
    metadata,
    !!!PC_columns
  )
  CheckDataFrame(data = PCA_plot_tibble)

  index <- which(colnames(PCA_plot_tibble) == color_factor)
  # PCA_plot_tibble <- as.data.frame(PCA_plot_tibble)
  PCA_plot_tibble$factor <- factor(PCA_plot_tibble[[index]])

  for (i in 2:numPC){
    plot <- ggplot2::ggplot(data = PCA_plot_tibble,  mapping =  ggplot2::aes_string(x = "PC_1",
                                                                                    y = paste("PC", i, sep = "_"),
                                                                                    label = "conditions",
                                                                                    color = color_factor)) +
      ggplot2::theme_classic() +
      ggplot2::geom_point() +
      ggplot2::labs(x = sprintf("PC1 (%.1f%%)", variance[1]), y = sprintf("PC%d (%.1f%%)", i, variance[i]))

    if (isFALSE(labels)){
      outputs_PCA[[paste0("PCA_plot_PC", i)]] <- plot
    } else{
      plot <- plot +  ggrepel::geom_text_repel(size = 2, show.legend = FALSE)
      outputs_PCA[[paste0("PCA_plot_labels_PC", i)]] <- plot
    }
  }

  return(outputs_PCA)

}

RunPCA <- function(data,
                   metadata,
                   name_sep,
                   numPC,
                   color_factor,
                   labels,
                   verbose = TRUE){

  vst_matrix <- as.matrix(data)
  CheckDataFrame(data = vst_matrix)

  # Generate transpose of feature by condition matrix
  condition_by_feature_matrix <- t(vst_matrix)
  CheckDataFrame(data = condition_by_feature_matrix)

  # remove features with too low variances, if any
  too_low_variance_features <- which(matrixStats::colVars(condition_by_feature_matrix, useNames = FALSE) < 1E-5)

  if (length(too_low_variance_features) > 1) {
    condition_by_feature_matrix <- condition_by_feature_matrix[ , -c(too_low_variance_features)]
    CheckDataFrame(data = condition_by_feature_matrix)
  }

  # Run PCA
  PCA_res <- prcomp(condition_by_feature_matrix, scale = TRUE, center = TRUE)

  # Examine amount of variance explained
  PC_variance_explained = 100 * (PCA_res$sdev ^ 2) / sum(PCA_res$sdev ^ 2)

  if (verbose) message("- Producing Elbow plot.")
  elbow_plot <- ProduceElbowPlot(data = PCA_res, variance = PC_variance_explained)

  if (verbose) message("- Producing PCA plots.")
  pca_plots <- ProducePCAPlot(data = PCA_res,
                              variance = PC_variance_explained,
                              metadata = metadata,
                              numPC = numPC,
                              color_factor = color_factor,
                              labels = labels)

  return(list(elbow_plot = elbow_plot, pca_plots = pca_plots))

}

#' Perform Differential Expression Analysis Using DESeq2
#'
#' @param data A matrix to analyze in the format of features (rows) per conditions (columns).
#' @param conditions A vector with the labels for each section of the conditions labels.
#' @param name_sep Specification of the notation separation used in the condition labels to run a DESeq2 analysis.
#' @param formula Design formula to use for the DESeq2 analysis. The name of the factors needs to be consistent with the column names of the \code{conditions}.
#' @param targets Dataset containing one column with the conditions to select, and another columns with the labels to use for the comparisons.
#' @param fc_threshold Fold change threshold to be used in the volcano plot (applicable when using \code{targets}).
#' @param pval_threshold  P-value threshold to be used in the volcano plot (applicable when using \code{targets}).
#' @param reduce Optional integer value to specify the factor to divide the values of the codon usage table if exceeded the maximum enabled by R.
#' @param heatmap Boolean variable to indicate if a heatmap should be displayed (can not be performed using \code{targets}).
#' @param PCA Boolean variable to indicate if a principal component analysis should be performed (can not be performed using \code{targets}).
#' @param numPC Number of principal components (PC) to be considered in the PCA analysis (if \code{PCA} is TRUE).
#' @param color_factor String to specify the factor to color the data points (if \code{PCA} is TRUE). The name needs to be consistent with one column name of the \code{conditions}.
#' @param labels Boolean variable to indicate if labels should be included in the PCA plots (if \code{PCA} is TRUE).
#' @param verbose A boolean parameter to specify if the messages within the function should be display.
#'
#' @return List of outputs: (i) Heatmap, (ii) PCA plot, and (iii) Size corrected \code{data}. Each element stored in the list of outputs can be accessed using '$'.
#' @export
#'
#' @examples
#' data(mRNA_data)
#' differential_expression_mRNA_analysis <- DESeq2runner(data = mRNA_data,
#'                                                       conditions = c("tissue", "cell.type"),
#'                                                       name_sep = "-",
#'                                                       formula = ~ tissue,
#'                                                       heatmap = TRUE,
#'                                                       PCA = TRUE,
#'                                                       numPC = 5,
#'                                                       color_factor = "tissue",
#'                                                       labels = FALSE)
#' targets_neuron <- data.frame(search = c("neuron", "ENS neurons"),
#'                              class = c("neuron", "other"))
#' differential_expression_mRNA_analysis_targeted <- DESeq2runner(data = mRNA_data,
#'              conditions = c("tissue", "cell.type"),
#'              name_sep = "-",
#'              formula = ~ class,
#'              targets = targets_neuron,
#'              fc_threshold = 1,
#'              pval_threshold = 0.05)

DESeq2runner <- function(data,
                         conditions,
                         name_sep,
                         formula,
                         targets = NULL,
                         fc_threshold = 1,
                         pval_threshold = 0.05,
                         reduce = 10000,
                         heatmap = TRUE,
                         PCA = TRUE,
                         numPC = 2,
                         color_factor = NULL,
                         labels = FALSE,
                         verbose = TRUE){

  metadata <- data.frame(label = colnames(data), stringsAsFactors = FALSE)
  metadata <- tidyr::separate(metadata, label, into = conditions, sep = name_sep)
  metadata[] <- lapply(metadata, function(x) if (is.character(x)) as.factor(x) else x)
  metadata$conditions <- colnames(data)
  CheckDataFrame(data = metadata)

  if (verbose) message("- Running differential expression analysis.\n")
  DESeq2_run <- ComputeDESeq2(data = data,
                              metadata = metadata,
                              formula = formula,
                              targets = targets,
                              reduce = reduce)
  if (verbose) message("- Differential expression analysis completed.\n")

  if (is.null(targets)){
    if (verbose) message("- Computing variance stabilization.")
    vst <- DESeq2::varianceStabilizingTransformation(DESeq2_run)
    vst <- SummarizedExperiment::assay(vst)
    CheckDataFrame(data = vst)

    if (heatmap == TRUE){
      if (verbose) message("- Generating heatmap with Euclidean distances.")
      Dist_heatmap <- ProduceHeatmapDiffExp(data = vst)
      Dist_heatmap <- recordPlot()
    }

    if (PCA == TRUE){
      if (is.null(color_factor)){
        stop("Please specify the `color_factor` parameter to be used to color the data points.")
      } else if (!(color_factor %in% colnames(metadata))){
        stop("Please specify a `color_factor` parameter present in the `conditions` used as input.")
      }

      if (verbose) message("- Running principal component analysis with ", numPC, " principal components.")
      PCA_results <- RunPCA(data = vst,
                            metadata = metadata,
                            numPC = numPC,
                            color_factor = color_factor,
                            labels = labels,
                            verbose = verbose)
    }

    if (verbose) message("- Computing size correction to account for sequencing depth.")
    size_corrected_output_matrix <- ComputeSizeCorrection(data = DESeq2_run, runDESeq2 = FALSE, verbose = verbose)
    CheckDataFrame(data = size_corrected_output_matrix)

    if (heatmap == TRUE && PCA == TRUE){
      return(list(heatmap = Dist_heatmap, PCA_results = PCA_results, size_corrected_data = size_corrected_output_matrix))
    } else if (heatmap == TRUE && PCA == FALSE){ # THIS CASE SEEMS TO NOT WORK PROPERLY
      return(list(heatmap = Dist_heatmap, size_corrected_data = size_corrected_output_matrix))
    } else if (heatmap == FALSE && PCA == TRUE){
      return(list(PCA_results = PCA_results, size_corrected_data = size_corrected_output_matrix))
    } else{
      return(list(size_corrected_data = size_corrected_output_matrix))
    }

  } else{

    contrast_vect <- DESeq2_run[[2]]
    DESeq2_run_res <- DESeq2_run[[1]]

    target_DESeq2_results <- as.data.frame(DESeq2::results(DESeq2_run_res, contrast = contrast_vect))

    target_results_tibble <- tibble::tibble(
      feature = rownames(data),
      log2_FC = target_DESeq2_results$log2FoldChange,
      neg_log10_adjusted_p_value = -log10(target_DESeq2_results$padj)
    ) %>%
      dplyr::filter(!is.na(log2_FC) & !is.na(neg_log10_adjusted_p_value))  # Remove NA values


    if (verbose) message("- Generating volcano plot.")
    volcano_plot <- ggplot2::ggplot() +
      ggplot2::theme_classic() +
      ggplot2::geom_point(data = target_results_tibble,
                          mapping = ggplot2::aes(x = log2_FC, y = neg_log10_adjusted_p_value), color = "black", alpha = 0.5) +
      ggplot2::geom_point(data = dplyr::filter(target_results_tibble, abs(log2_FC) > fc_threshold, neg_log10_adjusted_p_value > -log10(pval_threshold)),
                          mapping = ggplot2::aes(x = log2_FC, y = neg_log10_adjusted_p_value), size = 3) +
      ggrepel::geom_text_repel(data = dplyr::filter(target_results_tibble,
                                                    abs(log2_FC) > fc_threshold,
                                                    neg_log10_adjusted_p_value > -log10(pval_threshold)),
                               mapping = ggplot2::aes(x = log2_FC, y = neg_log10_adjusted_p_value, label = feature),
                               size = 2) +
      ggplot2::geom_abline(slope = 0, intercept = -log10(pval_threshold), linetype = "dotted") +
      ggplot2::geom_vline(xintercept = -1 * fc_threshold, linetype = "dotted") +
      ggplot2::geom_vline(xintercept = fc_threshold, linetype = "dotted") +
      ggplot2::labs(x = expression(log[2]~fold~change), y = expression(-log[10]~adjusted~p~value), title = "brain neurons vs. other cell types") +
      ggplot2::theme(plot.title = ggplot2::element_text(hjust = 0.5, size = 20))

    # output: (1) neuron DESeq2 results in tibble format, (2) volcano plot
    return(list(target_results_tibble, volcano_plot))
  }

}

CheckDataNormalized <- function(data){
  if (all(data == floor(data))){ # Data likely to be raw (all integers)
    return(TRUE)
  } else{ # Data likely to be normalized (contain decimals)
    return(FALSE)
  }
}
