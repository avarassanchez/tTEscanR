#' @importFrom stats setNames
#'
NULL

IsIn_tTEscanR_Object <- function(object,
                                 section,
                                 update.assay = FALSE,
                                 overwrite = FALSE,
                                 verbose = TRUE){

  if (section %in% names(object@assays)){
    if (verbose) message("- A ", section, " assay exists in the input object.")

    if (!isFALSE(update.assay)){
      if (isFALSE(overwrite)){
        stop("- Specify another `assay` for ", section, " or change the input parameter `overwrite` to TRUE.")
      } else {
        if (verbose) message("- The assay ", section, " will be overwritten")
      }
    }

  } else {
    if (isFALSE(update.assay)){
      stop("- A ", section, " assay does not exist in the input object.")
    } else {
      if (verbose) message("- The assay ", section, " will be defined.")
    }
  }

}

ExistMetadata_tTEscanR_Object <- function(object,
                                          section,
                                          update.metadata = FALSE,
                                          overwrite = FALSE,
                                          verbose = TRUE){

  if (section %in% names(object@meta.data)){
    if (verbose) message("- A ", section, " metadata variable exists in the input object.")

    if (!isFALSE(update.metadata)){
      if (isFALSE(overwrite)){
        stop("- Specify another `meta.data.id` for ", section, " or change the input parameter `overwrite` to TRUE.")
      } else {
        if (verbose) message("- The metadata ", section, " will be overwritten")
      }
    }
  } else {
    if (isFALSE(update.metadata)){
      stop("- A ", section, " metadata variabledoes not exist in the input object.")
    } else {
      if (verbose) message("- The metadata ", section, " will be defined.")
    }
  }
}

ExistColumnInData <- function(data,
                              column_names){
  columns_in_data <- all(column_names %in% colnames(data))

  if(isFALSE(columns_in_data)){
    stop("Not all input column names could be found in the input data.\n",
         "Please check `x_axis_col`, `y_axis_col` and `condition_col` input parameters.")
  }
}

CheckDataInLongFormat <- function(data,
                                  compute = FALSE) {

  num_cols <- sapply(data, is.numeric) # One numeric column
  cat_cols <- sapply(data, is.character) | sapply(data, is.factor) # One categorical column

  is_long <- any(cat_cols) & any(num_cols) # Will return TRUE if the data is in long format

  if(isFALSE(is_long) && isFALSE(compute)){
    stop("The input data needs to be in long format, containing at least one numeric and one categorical colummn.")
  } else if(isFALSE(is_long) && !isFALSE(compute)){
    return(is_long)
  }
}

DataToLongFormat <- function(data,
                             rownames_to_column,
                             names_to,
                             values_to){

  long_format <- sweep(data, 2, colSums(data), FUN = "/") %>%
    as.data.frame() %>%
    tibble::rownames_to_column(var = rownames_to_column) %>%
    pivot_longer(., c(-rownames_to_column), names_to = names_to, values_to = values_to)

  return(long_format)

}

CheckCodonFreqTable <- function(data,
                                species,
                                filter = NULL,
                                verbose = TRUE){

  if (is.null(data)){

    if (verbose) message("- No `codon_freq` has been given as input.")

    if (is.null(species)){
      stop("No `codon_freq` has been given as input and no `species` is specified to use the default codon frequency per gene table.\n",
           "Please, specify `hg38` for human or `mm39` for mouse default data.")
    }

    if (is.null(filter)){
      if (verbose) message("- No `filter` has been given as input.\n",
                           "- The canonical trasncript will be retained")
      filter <- "canonical"
    } else if(filter != "canonical" && filter != "length"){
      if (verbose) message("- An invalid `filter` has been given as input.\n",
                           "Please leave it empty or specify `canonical` or `length`.")
    }

    codon_frequency_per_gene_table <- SelectDefaultData(action = "codon_freq", species = species, filter = filter)

  } else{
    codon_frequency_per_gene_table <- data
    CheckDataFrame(data = codon_frequency_per_gene_table, names = TRUE)
  }

  if (verbose) message("- Filtering the codon frequency per gene table by the sense codons.")
  codon_frequency_per_gene_table <- codon_frequency_per_gene_table[sense_codons, ]

  return(codon_frequency_per_gene_table)
}

#' Filter Out Conditions With Low tRNA Cuts
#'
#' @param tRNA_data The tRNA gene expression data containing tRNA cuts (rows) and conditions (columns).
#' @param cutoff  Integer to be used as low boundary for the filtering.
#'
#' @return Filtered \code{tRNA_data}.
#' @export
#'
#' @examples
#' data(tRNA_data)
#' tRNA_data_filtered <- tRNACutsFilter(tRNA_data = tRNA_data, cutoff = 5000)

tRNACutsFilter <- function(tRNA_data,
                           cutoff = 5000){

  column_name_counts <- Matrix::colSums(tRNA_data)
  unique_column_names <- names(column_name_counts)[column_name_counts < cutoff]
  indices <- which(colnames(tRNA_data) %in% unique_column_names)

  if(!is.null(indices)){
    tRNA_data <- tRNA_data[, -indices]
  }

  return(tRNA_data)
}

IsEnsemblID <- function(gene_vector,
                        action,
                        notation = NULL) {

  annotation <- grepl("^ENS[A-Z]*[0-9]+$", gene_vector)

  if (length(unique(annotation)) > 1){
    if (action == "check") stop("There are gene annotation inconsistencies in the gene vector.")

    if (action == "translate"){
      if (is.null(notation)){
        stop("There are gene annotation inconsistencies in the gene vector.\n",
             "Please, specify a suitable `notation` parameter.\n",
             "Supported formats: id for Ensembl ID and symbol for gene name.")
      } else if (notation == "id"){
        return("Gene Symbol")
      } else if (notation == "symbol"){
        return("Ensembl ID")
      } else {
        stop("Please, specify a suitable `notation` parameter.\n",
             "Supported formats: id for Ensembl ID and symbol for gene name.")
      }
    }

  } else {
    if(all(annotation)) return("Ensembl ID") else return("Gene Symbol")
  }
}

CheckGeneAnnotation <- function(vector1,
                                vector2,
                                translate = FALSE,
                                verbose = TRUE){

  format1 <- IsEnsemblID(vector1, action = "check")
  format2 <- IsEnsemblID(vector2, action = "check")

  if (format1 == format2) {
    if (verbose) message("Both vectors are in the same format: ", format1, ".")
  } else {
    if (translate == FALSE){
      stop("The vectors have different formats: vector1 in ", format1, " and vector2 in ", format2, ".")
    } else{
      if (verbose) message("The vectors are not in the same format: vector1 in ", format1, " and vector2 in ", format2, ".")
      return(format2)
    }
  }
}

CheckDataFrame <- function(data,
                           names = TRUE){

  if (is.null(data)){
    stop("The dataset is empty or could not be found.")

  } else{
    # Based the selection of columns in 2 so to be sure that the `translator_table` is given in a correct format
    if (ncol(data) < 2 || nrow(data) == 0) stop("Incorrect dimensions of the dataset.")
    if (names == TRUE && (is.null(rownames(data)) || is.null(colnames(data)))) stop("The labels of the dataset could not be found.\n",
                                                                                    "Check that rownames() and columnames() do not give empty outcomes.")
  }
}

SelectDefaultData <- function(action,
                              species = NULL,
                              filter = NULL){

  if (is.null(action)){
    stop("In order to load a default dataset you must specify the `action` input parameter. \n",
         "Supported formats: translator_table and codon_freq.")
  }
  if (is.null(species)){
    stop("To use a default dataset specify a suitable `species` input.")

  } else{
    if(species != "hg38" && species != "mm39"){
      stop("Incorrect `species` input name.\n",
           "Supported formats: hg38 for human and mm39 for mouse.")

    } else{
      message("- The default dataset: ", species, " will be used.")

      if (action == "translator_table"){
        if (species == "hg38") translator_table <- human_hg38_translator_table else translator_table <- mouse_mm39_translator_table
        return(translator_table)

      } else if (action == "codon_freq"){
        if(filter != "length" && filter != "canonical") {
          stop("Incorrect `filter` input name. \n",
               "Supported formats: length and cannonical.")
        }

        if (species == "hg38") {
          if (filter == "length") codon_freq <- human_codon_freq_per_gene_table_length else codon_freq <- human_codon_freq_per_gene_table_canonical
        } else {
          if (filter == "length") codon_freq <- mouse_codon_freq_per_gene_table_length else codon_freq <- mouse_codon_freq_per_gene_table_canonical
        }

        return(codon_freq)
      }
    }
  }
}

IdentifyInputFormat <- function(data){

  if(is.character(data)){
    format <- "vector"
  } else if (is.data.frame(data) || is.matrix(data) || inherits(data, "dgCMatrix")){
    format <- "table"
    CheckDataFrame(data)
  } else if (inherits(data, "list")){
    for (i in 1:length(data)){
      if (is.data.frame(data[[i]]) || is.matrix(data[[i]]) || inherits(data[[i]], "dgCMatrix")){
        format <- "list"
      } else {
        stop("Incorrect data format.\n",
             "Supported formats: vector, dataframe or matrix.")
      }
    }
  } else {
    stop("Incorrect data format.\n",
         "Supported formats: vector, dataframe or matrix.")
  }

  return(format)
}

#' Translate Ensembl IDs and Gene Names
#'
#' @param data_to_translate A vector or table containing the gene names to translate.
#' @param translator_table (Optional) A user-provided translator gene table (1st column - Ensembl ids, 2nd column - gene symbol).
#' @param species (Optional) Species' reference genome version (required if \code{translator_table} is not provided).
#' @param position (Optional) Genes' location if the \code{data_to_translate} is a table.
#' @param notation (Optional) Genes' annotation to use in case of inconsistencies within the \code{data_to_translate}.
#' @param verbose Logical; if TRUE, displays information messages.
#'
#' @return Translated genes from \code{data_to_translate}.
#' @export
#'
#' @examples
#' data(mRNA_data)
#' translated_mRNA_data <- TranslateGeneName(data_to_translate = mRNA_data,
#'                                           species = "hg38",
#'                                           position = "row",
#'                                           notation = "id") # short to ENSG
#' translated_mRNA_data <- TranslateGeneName(data_to_translate = translated_mRNA_data,
#'                                           species = "hg38",
#'                                           position = "row",
#'                                           notation = "symbol") # ENSG to short

TranslateGeneName <- function(data_to_translate,
                              translator_table = NULL,
                              species = NULL,
                              position = NULL,
                              notation,
                              verbose = TRUE){

  if (verbose) message("1. Checking the `data_to_translate` input.")
  if(notation != "id" && notation != "symbol"){
    stop("Incorrect `notation` input value.\n", "Supported formats: id or symbol.")
  }

  format_input <- IdentifyInputFormat(data = data_to_translate)

  if (verbose) message("2. Loading the `translator_table` input.")
  if (is.null(translator_table)){
    if (verbose) message("- No `translator_table` has been given as input.")
    gene_trans <- SelectDefaultData(action = "translator_table", species = species)
    gene_trans <- gene_trans[!apply(gene_trans == "", 1, any), ]
  } else{
    gene_trans <- translator_table
    gene_trans <- gene_trans[!apply(gene_trans == "", 1, any), ]
    CheckDataFrame(data = gene_trans, names = FALSE)
  }

  if (verbose) message("3. Extracting the vector of genes to translate.")
  if (format_input == "table"){
    if (is.null(position)){
      stop("Specify a value for the `position` input.\n", "Supported formats: row or column.")
    } else if (position == "row"){
      genes <- rownames(data_to_translate)
    } else if (position == "column"){
      genes <- colnames(data_to_translate)
    } else{
      stop("Incorrect `position` input value.\n", "Supported formats: row or column.")
    }
  } else{
    genes <- data_to_translate
  }

  if (verbose) message("4. Assessing the gene annotation.")
  format <- IsEnsemblID(genes, action = "translate", notation = notation)
  if (format == "Ensembl ID" && notation == "symbol"){
    if (verbose) message("- The genes will be converted to gene symbol annotations.")
    tr <- setNames(gene_trans[ ,2], nm = gene_trans[ ,1])
    missing <- intersect(genes, gene_trans[, 1])
  } else if (format == "Gene Symbol" && notation == "id"){
    if (verbose) message("- The genes will be converted to Ensembl id annotations.")
    tr <- setNames(gene_trans[ ,1], nm = gene_trans[ ,2])
    missing <- intersect(genes, gene_trans[, 2])
  } else{
    stop("The genes are in the same annotation format: ", format)
  }

  if (verbose) message("5. Translating the gene annotations.")

  if (length(missing) == 0){
    stop("There are no intersecting genes with respect to the `translator_table`.")
  } else if (length(missing) != length(genes)){
    if (verbose) message("- Not all genes have a translation.\n", "- Genes without a translation will be filtered out.")
    genes <- missing
  }

  translated_genes <- dplyr::recode(genes, !!!tr)

  if (verbose) message("6. Assessing if there are duplicated genes.")
  duplicates <- unique(translated_genes[duplicated(translated_genes)])

  if (length(duplicates) > 0){
    if (verbose) {
      message("- There are duplicated genes:")

      for (i in 1:length(duplicates)){
        message(duplicates[i])
      }
    }

    if (verbose) message("- Just the first appearance of the gene has been retained.")
    duplicated_indices <- which(duplicated(translated_genes) | duplicated(translated_genes, fromLast = TRUE))
    translated_genes <- translated_genes[-duplicated_indices]
    genes <- genes[-duplicated_indices]

  } else {
    if (verbose) message("- There are no duplicated genes.")
  }

  if (format_input == "table"){
    if (position == "row") {
      data_to_translate <- data_to_translate[genes, ]
      rownames(data_to_translate) <- translated_genes
    } else {
      data_to_translate <- data_to_translate[, genes]
      colnames(data_to_translate) <- translated_genes
    }
    return(data_to_translate)

  } else {
    return(translated_genes)
  }
}
