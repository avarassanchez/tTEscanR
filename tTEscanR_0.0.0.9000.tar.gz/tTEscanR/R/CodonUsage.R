#' @importFrom dplyr group_by summarize
#' @importFrom tidyr pivot_longer
#' @importFrom magrittr %>%
#' @importFrom stats cor
utils::globalVariables(c("codon", "usage", "."))
NULL

#' Compute Codon Usage from mRNA Gene Expression Data
#'
#' @param object A \code{tTEscanR_Object} containing a mRNA assay.
#' @param codon_freq (Optional) A user-provided codon frequency per gene table.
#' @param species (Optional) Species' reference genome version (required if \code{codon_freq} is not provided).
#' @param filter (Optional) Transcript selection criteria if multiple per gene (required if \code{codon_freq} is not provided).
#' @param translate Logical; if TRUE, translates incoherent genes' annotations.
#' @param reduce (Optional) Integer factor to use as normalization if integer values exceed the maximum enabled by R.
#' @param compute_codon_exonic_background Logical; if TRUE, computes the codon exonic background.
#' @param compute_mean_codon_usage Logical; if TRUE, computes the mean codon usage.
#' @param conditions (Optional) A vector with the labels for each section of the conditions labels.
#' @param name_sep (Optional) Specification of the notation separation used in the condition labels to run a DESeq2 analysis.
#' @param formula (Optional) Design formula to use for the DESeq2 analysis. The name of the factors needs to be consistent with the column names of the \code{conditions}.
#' @param compute_correlation_background_mean Logical; if TRUE, computes the correlation between the codon exonic background and the mean codon usage should be computed (in case these two parameters are set to TRUE).
#' @param overwrite.assay Logical; if TRUE, overwrites the assay (if already present in the \code{tTEscanR_Object}).
#' @param overwrite.metadata Logical; if TRUE, overwrites the metadata (if already present in the \code{tTEscanR_Object}).
#' @param verbose Logical; if TRUE, displays information messages.
#'
#' @return An updated \code{tTEscanR_Object} containing a new layer of information representing the codon usage.
#' @export
#'
#' @examples
#' data(mRNA_data)
#' mRNA_data_translated <- TranslateGeneName(data_to_translate = mRNA_data,
#'                                           species = "hg38",
#'                                           position = "row",
#'                                           notation = "id")
#' tTEobj <- Create_tTEscanR_Object(counts = mRNA_data_translated, assay = "mRNA")
#' tTEobj <- ComputeCodonUsage(object = tTEobj,
#'                             codon_freq = NULL,
#'                             species = "hg38",
#'                             filter = "canonical",
#'                             reduce = 10000)
#' tTEobj <- ComputeCodonUsage(object = tTEobj,
#'                             codon_freq = NULL,
#'                             species = "hg38",
#'                             filter = "length",
#'                             reduce = 10000,
#'                             overwrite.assay = TRUE,
#'                             overwrite.metadata = TRUE)

ComputeCodonUsage <- function(object,
                              codon_freq = NULL,
                              species = NULL,
                              filter = NULL,
                              translate = FALSE,
                              reduce = 10000,
                              compute_codon_exonic_background = TRUE,
                              compute_mean_codon_usage = TRUE,
                              conditions = NULL,
                              name_sep = NULL,
                              formula = NULL,
                              compute_correlation_background_mean = TRUE,
                              overwrite.assay = TRUE,
                              overwrite.metadata = TRUE,
                              verbose = TRUE){

  if (verbose) message("1. Evaluating the input tTEscanR object.")
  if (!inherits(object, 'tTEscanR_Object')){
    stop("`object` must be a tTEscanR object.")
  }

  IsIn_tTEscanR_Object(object = object, section = "mRNA", verbose = verbose)
  CheckDataFrame(data = object@assays$mRNA)

  if (verbose) message("2. Checking the codon frequency per gene table.")
  codon_frequency_per_gene_table <- CheckCodonFreqTable(data = codon_freq, species = species, filter = filter, verbose = verbose)

  if (verbose) message("3. Evaluating consistency across gene annotations.\n",
                       "- Vector 1: codon frequency per gene table\n",
                       "- Vector 2: mRNA gene expression data")
  gene_annotation <- CheckGeneAnnotation(vector1 = colnames(codon_frequency_per_gene_table),
                                         vector2 = rownames(object@assays$mRNA),
                                         translate = translate, verbose = verbose)

  if(!is.null(gene_annotation)){
    if (verbose) {
      message("The gene annotation of the codon frequency per gene table will be translated into the ", gene_annotation, " format.")
      message("------------------------------")
    }
    gene_annotation <- ifelse(gene_annotation == "Ensembl ID", "id", "symbol")
    codon_frequency_per_gene_table <- TranslateGeneName(data_to_translate = codon_frequency_per_gene_table, species = species,
                                                        position = "column", notation = gene_annotation,
                                                        verbose = verbose)
    if (verbose) message("------------------------------")
  }

  if (verbose) message("4. Retrieving common mRNAs (gene expression and codon frequency table).")
  mRNAs_in_common <- intersect(colnames(codon_frequency_per_gene_table), rownames(object@assays$mRNA))
  metadata <- list(mRNAs_in_common)
  metadata_ids <- list("mRNAsInCommon")

  if (verbose) message("- Filtering the datasets based on the common mRNAs.")
  filtered_mRNA_gene_expression <- as.matrix(object@assays$mRNA[mRNAs_in_common, ])
  filtered_codon_frequency_per_gene_table <- as.matrix(codon_frequency_per_gene_table[ , mRNAs_in_common])
  CheckDataFrame(data = filtered_codon_frequency_per_gene_table)

  if (verbose) message("5. Computing the codon usage matrix.")
  codon_usage_per_condition <- filtered_codon_frequency_per_gene_table %*% filtered_mRNA_gene_expression
  CheckDataFrame(data = as.matrix(codon_usage_per_condition))

  if (verbose) message("- Evaluating values in the codon usage matrix.")
  if (any(codon_usage_per_condition > .Machine$integer.max)){
    codon_usage_per_condition <- codon_usage_per_condition / reduce
    codon_usage_per_condition <- round(codon_usage_per_condition)
    CheckDataFrame(data = codon_usage_per_condition)

    if (verbose) message("- Some values of the computed matrix exceed the maximum value accepted by R.\n",
                         paste("- The matrix has been divided by the factor, `reduce` = ", reduce,"."))
  }

  if (isTRUE(compute_codon_exonic_background) || isTRUE(compute_mean_codon_usage) || isTRUE(compute_correlation_background_mean)){
    if (verbose) message("6. Computing additional metrics.")
  }

  if (isTRUE(compute_codon_exonic_background)){
    if (verbose) message("- Computing the codon exonic background.")
    codon_exonic_background <- rowSums(filtered_codon_frequency_per_gene_table) / sum(rowSums(filtered_codon_frequency_per_gene_table))
    metadata <- append(metadata, list(codon_exonic_background))
    metadata_ids <- append(metadata_ids, "CodonExonicBackground")
  }

  if(isTRUE(compute_mean_codon_usage)){
    if (verbose) {
      message("- Computing the mean codon usage.")
      message("------------------------------")
    }
    mean_codon_usage <- ComputeMeanUsage(data = codon_usage_per_condition,
                                         conditions = conditions, name_sep = name_sep, formula = formula,
                                         verbose = verbose)
    if (verbose) message("------------------------------")

    if(isFALSE(compute_codon_exonic_background)){
      metadata <- append(metadata, mean_codon_usage)
      metadata_ids <- append(metadata_ids, "MeanCodonUsage")
    }
  }

  if (isTRUE(compute_codon_exonic_background) && isTRUE(compute_mean_codon_usage) && isTRUE(compute_correlation_background_mean)){
    if (verbose) message("- Computing the correlation between the mean codon usage and the codon exonic background.")
    correlation_background_mean <- ComputeCorrelationBackground(mean = mean_codon_usage, background = codon_exonic_background)

    metadata <- append(metadata, list(correlation_background_mean[[1]]))
    metadata_ids <- append(metadata_ids, "MeanCodonUsage")

    metadata <- append(metadata, list(correlation_background_mean[[2]]))
    metadata_ids <- append(metadata_ids, "Correlation_Background_MeanCodonUsage")
  } else if(isTRUE(compute_codon_exonic_background) && isFALSE(compute_mean_codon_usage) || isFALSE(compute_correlation_background_mean)){
    message("- The codon exonic background could not be computed as either `compute_mean_codon_usage` or `compute_correlation_background_mean are not enabled.")
  }

  if (verbose) message("7. Updating the tTEscanR object.")
  object <- Update_tTEscanR_Object(object = object,
                                   counts = codon_usage_per_condition,
                                   assay = "CodonUsage",
                                   meta.data = metadata,
                                   meta.data.ids = metadata_ids,
                                   overwrite.assay = overwrite.assay,
                                   overwrite.metadata = overwrite.metadata,
                                   verbose = verbose)

  return(object)
}

#' Compute Anticodon Usage from tRNA Gene Expression Data
#'
#' @param object A \code{tTEscanR_Object} containing a tRNA assay.
#' @param overwrite.assay Logical; if TRUE, overwrites the assay (if already present in the \code{tTEscanR_Object}).
#' @param overwrite.metadata Logical; if TRUE, overwrites the metadata (if already present in the \code{tTEscanR_Object}).
#' @param verbose Logical; if TRUE, displays information messages.
#'
#' @return An updated \code{tTEscanR_Object} containing a new layer of information representing the anticodon usage.
#' @export
#'
#' @examples
#' data(tRNA_data)
#' tTEobj <- Create_tTEscanR_Object(counts = tRNA_data, assay = "tRNA")
#' tTEobj <- ComputeAnticodonUsage(object = tTEobj)

ComputeAnticodonUsage <- function(object,
                                  overwrite.assay = FALSE,
                                  overwrite.metadata = FALSE,
                                  verbose = TRUE){

  if (verbose) message("1. Evaluating the input tTEscanR object.")
  if (!inherits(object, 'tTEscanR_Object')){
    stop("`object` must be a tTEscanR object.")
  }

  IsIn_tTEscanR_Object(object = object, section = "tRNA", verbose = verbose)
  CheckDataFrame(data = object@assays$tRNA)

  # Need to check that the rownames correspond to the tRNA genes and that the format is compatible
  if (verbose) message("2. Extracting anticodons for each tRNA gene.")
  anticodons_for_tRNA_genes <- sapply(strsplit(rownames(object@assays$tRNA), "-"), "[[", 3)
  unique_anticodons <- sort(unique(anticodons_for_tRNA_genes))

  anticodon_usage_per_condition <- matrix(data = 0, nrow = length(unique_anticodons), ncol = length(colnames(object@assays$tRNA)))
  dimnames(anticodon_usage_per_condition) <- list(unique_anticodons, colnames(object@assays$tRNA))
  CheckDataFrame(data = anticodon_usage_per_condition)

  if (verbose) message("3. Pooling counts from each tRNA gene with a particullar anticodon.")
  for (i in 1:length(unique_anticodons)) {
    anticodon_usage_per_condition[i, ] <- Matrix::colSums(object@assays$tRNA[which(anticodons_for_tRNA_genes == unique_anticodons[i]), , drop = FALSE])
  }

  CheckDataFrame(data = anticodon_usage_per_condition)

  if (verbose) message("4. Updating the tTEscanR object.")
  metadata <- list(anticodons_for_tRNA_genes)
  metadata_ids <- list("tRNAsAnticodons")
  object <- Update_tTEscanR_Object(object = object,
                                   counts =  anticodon_usage_per_condition,
                                   assay = "AnticodonUsage",
                                   meta.data = metadata,
                                   meta.data.ids = metadata_ids,
                                   overwrite.assay = overwrite.assay,
                                   overwrite.metadata = overwrite.metadata,
                                   verbose = verbose)

  return(object)
}

ComputeCorrelationBackground <- function(mean,
                                         background){

  correlation_to_exonic_background <- round(cor(mean$mean_usage_across_conditions,
                                                background, method = "spearman"), 3)
  mean$exonic_background_usage <- background

  return(list(mean, correlation_to_exonic_background))
}

#' Compute Usage Across Conditions (Mean Usage)
#'
#' @param data A \code{tTEscanR_Object} or count matrix (codon, anticodon or amino acids).
#' @param assay (Optional) Assay's label to be retrieved if `data` is a \code{tTEscanR_Object}.
#' @param conditions (Optional) A vector with the labels for each section of the conditions labels (to run a DESeq2 analysis if input `data` is not size-corrected).
#' @param name_sep (Optional) Specification of the notation separation used in the condition labels (to run a DESeq2 analysis if input `data` is not size-corrected).
#' @param formula (Optional) Design formula (to run a DESeq2 analysis if input `data` is not size-corrected). The name of the factors needs to be consistent with the column names of the \code{conditions}.
#' @param verbose Logical; if TRUE, displays information messages.
#'
#' @return A table containing a new layer of information representing the mean codon usage.
#' @export
#'
#' @examples
#' data(mRNA_data)
#' mRNA_data_translated <- TranslateGeneName(data_to_translate = mRNA_data,
#'                                           species = "hg38",
#'                                           position = "row",
#'                                           notation = "id")
#' tTEobj <- Create_tTEscanR_Object(counts = mRNA_data_translated, assay = "mRNA")
#' tTEobj <- ComputeCodonUsage(object = tTEobj,
#'                             codon_freq = NULL,
#'                             species = "hg38",
#'                             filter = "canonical",
#'                             reduce = 10000)
#' tTEobj <- ComputeMeanUsage(data = tTEobj,
#'                            assay = "codon",
#'                            conditions = c("tissue", "cell.type"),
#'                            name_sep = "-",
#'                            formula = ~ tissue)

ComputeMeanUsage <- function(data,
                             assay = NULL,
                             conditions = NULL,
                             name_sep = NULL,
                             formula = NULL,
                             verbose = TRUE){

  if (verbose) message("- Evaluating the input.")
  if (inherits(data, 'tTEscanR_Object')){
    if (verbose) message("- The input is a tTEscanR object.\n",
                         "- Checking if the CodonUsage assay is in the object.")
    if(is.null(assay)){
      stop("- Please specify the `assay` from the tTEscanR object that needs to be used.")
    } else{
      if(assay == "codon"){
        IsIn_tTEscanR_Object(object = data, section = "CodonUsage", verbose = verbose)
        data <- data@assays$CodonUsage
      } else if(assay == "anticodon"){
        IsIn_tTEscanR_Object(object = data, section = "AnticodonUsage", verbose = verbose)
        data <- data@assays$AnticodonUsage
      } else if(assay == "AADemand"){
        IsIn_tTEscanR_Object(object = data, section = "AADemand", verbose = verbose)
        data <- data@assays$AADemand
      } else if(assay == "AASupply"){
        IsIn_tTEscanR_Object(object = data, section = "AASupply", verbose = verbose)
        data <- data@assays$AASupply
      } else{
        stop("- Please specify a valid `assay` input parameter: codon, anticodon, AADemand, AASupply.")
      }
    }
  } else {
    if (verbose) message("- The input is a table/matrix.")
  }

  # Check if the data is in long format
  if(isFALSE(CheckDataInLongFormat(data, compute = TRUE))){

    # Check if the data is normalized
    if (isFALSE(CheckDataNormalized(data))){
      if (verbose) {
        message("- Size correcting the usage matrix to account for sequencing depth.")
        message("------------------------------")
      }
      data <- ComputeSizeCorrection(data = data,
                                    runDESeq2 = TRUE,
                                    conditions = conditions,
                                    name_sep = name_sep,
                                    formula = formula)
      if (verbose) message("------------------------------")
    }

    if (verbose) message("- Changing the normalized usage matrix to a long format table.")
    data <- DataToLongFormat(data = data,
                             rownames_to_column = "codon",
                             names_to = "conditions",
                             values_to = "usage")
  } else{
    # Check that the codon and usage columns are in the table
    if(!"codon" %in% names(data)){
      stop("The codon column does not exist in the `data` input parameter.")
    } else if(!"usage" %in% names(data)){
      stop("The usage column does not exist in the `data` input parameter.")
    } else{
      message("- The data is in a proper long format.")
    }
  }

  if (verbose) message("- Calculating the mean usage across conditions.")
  usage_across_conditions <- group_by(data, codon) %>%
    summarize(mean_usage_across_conditions = mean(usage))

  return(usage_across_conditions)
}
