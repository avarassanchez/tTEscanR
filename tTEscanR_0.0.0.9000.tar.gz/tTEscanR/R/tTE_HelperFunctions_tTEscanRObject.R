#' tTEscanR Object Update
#' @description
#' Updates an existing \code{tTEscanR_object} using \code{\link{Create_tTEscanR_Object}}. For more details, refer to \code{\link{Create_tTEscanR_Object}}.
#'
#' @param object An existing \code{tTEscanR_Object}.
#' @param counts Optional; a count matrix (or \code{list} of matrices) that will be stored in the \code{assays} slot of the input \code{object}. Supported formats: \code{matrix}, \code{data.frame} and \code{list}.
#' @param assay Optional; a \code{character} string (or \code{list} of strings) specifying the name of the \code{counts}. Supported formats: \code{character} and \code{list}.
#' @param main_name Optional; a \code{character} string specifying the name of the \code{meta.data} if dealing with a \code{list} that needs to be added as a single element.
#' @param meta.data Optional; a \code{list} with additional information that will be stored in \code{meta.data} slot of the input \code{object}.
#' @param meta.data.ids Optional; a \code{list} with the labels to identify the \code{meta.data} (if \code{meta.data} is given).
#' @param overwrite_assay Logical; if \code{TRUE}, overwrites any existing assay in the \code{object} if the \code{assay} label coincides. Defaults to \code{FALSE}.
#' @param overwrite_metadata Logical; if \code{TRUE}, overwrites any existing metadata in the \code{object} if the \code{meta.data.ids} label coincides. Defaults to \code{FALSE}.
#' @param verbose Logical; if \code{TRUE}, displays information messages. Defaults to \code{TRUE}.
#'
#' @return An updated \code{tTEscanR_Object}.
#' @export
#'
#' @examples
#' data(subset_mRNA_data, subset_tRNA_data)
#' tTEscanR_obj <- Create_tTEscanR_Object(counts = subset_mRNA_data, assay = "mRNA")
#' tTEscanR_obj <- Update_tTEscanR_Object(object = tTEscanR_obj, counts = subset_tRNA_data,
#'                                        assay = "tRNA")

Update_tTEscanR_Object <- function(object, counts = NULL, assay = NULL, main_name = NULL, meta.data = NULL, meta.data.ids = NULL,
                                   overwrite_assay = FALSE, overwrite_metadata = FALSE, verbose = TRUE){

  ###
  # CALL: User or Create_tTEscanR_Object()
  # DESCRIPTION: This function adds new data and metadata to an existing tTEscanR object.
  # The code follows the same background structure as Create_tTEscanR_Object(), with the difference that there is already an object present.
  # In all cases it is required to check that the data is not already present, otherwise it is required to specify the overwrite parameters.
  ###

  message("1 . Initial assessment and addition of the input data.")
  if (!inherits(object, 'tTEscanR_Object')) stop("'object' must be a tTEscanR object.")
  if (verbose) message("- The input consists of a proper tTEscanR object.")

  # NOTHING TO ADD
  if (is.null(counts) && is.null(meta.data)) stop("Please specify either the parameter 'counts' or 'meta.data' to be added to the 'object'.")

  if (!is.null(counts)){ # ADDING COUNTS
    message("- Adding the 'counts' to the tTEscanR object.")
    object <- DefineNewData(object = object, slot = "assays", data = counts, id = assay, mode = "fix", action_update = TRUE, overwrite = overwrite_assay, verbose = verbose)
  }

  if (!is.null(meta.data)){ # ADDING METADATA
    message("- Adding the 'meta.data' to the tTEscanR object.")
    object <- DefineNewData(object = object, slot = "meta.data", data = meta.data, id = meta.data.ids, mode = "flexible",
                            main_name = main_name, action_update = TRUE, overwrite = overwrite_metadata, verbose = verbose)
  }

  message("1 . COMPLETED", "\n2 . Validating and returning the updated tTEscanR object.")
  validObject(object = object)
  message("2 . COMPLETED\n")
  return(object)
}


DefineNewData <- function(object = NULL, slot = NULL, data, id = NULL, action_update = FALSE, overwrite = FALSE, main_name = NULL, mode, verbose){

  ###
  # CALL: Create_tTEscanR_Object() and Update_tTEscanR_Object()
  # DESCRIPTION: This function controls the addition of data and metadata into a tTEscanR object.
  ###

  if (verbose) message("- Evaluating the parameters...")

  input_format <- IdentifyInputFormat(data = data, mode = mode)
  if (!input_format %in% c("list", "single")) stop("Internal error: IdentifyInputFormat returned an invalid 'mode.'")
  id <- CheckInputCombinations(data = data, labels = id, mode = input_format) # Check inputs and get final, validated IDs

  if (input_format == "single") data <- list(data)

  if(!action_update){
    names(data) <- id
    return(data)
  }

  for (i in seq_along(data)){
    curr_id <- id[i]
    curr_data <- data[[i]]

    if (is.null(main_name)){
      IsIn_tTEscanR_Object(object = object, slot = slot, section = curr_id, update_assay = TRUE, overwrite = overwrite, verbose = verbose)
      if (slot == "assays") object@assays[[curr_id]] <- curr_data else object@meta.data[[curr_id]] <- curr_data
    } else {
      if (is.null(object@meta.data[[main_name]])) object@meta.data[[main_name]] <- list()
      IsIn_tTEscanR_Object(object = object, slot = "meta.data", section = main_name, subset = curr_id, update_assay = TRUE, overwrite = overwrite, verbose = verbose)
      object@meta.data[[main_name]][[curr_id]] <- curr_data
    }
  }

  return(object)
}

CheckInputCombinations <- function(data, labels, mode = c("single", "list")){

  ###
  # CALL: Create_tTEscanR_Object() and Update_tTEscanR_Object()
  # DESCRIPTION: This function checks all input combinations that are suitable to be added to a tTEscanR object to avoid future inconsistencies.
  # If dealing with lists we can have named or unnamed lists. Named lists already have an identifier for each piece of data.
  # However, unnamed lists will require an extra input parameter to specify the identifiers.
  ###

  mode <- match.arg(mode)

  if (mode == "single") data <- list(data)

  if (is.null(labels)){
    data_names <- names(data)
    if (is.null(data_names) || all(data_names == "") || any(is.na(data_names))) stop("Please provide a named list or specify a suitable set of labels to identify the `data`.")
    labels <- data_names
  } else {
    labels <- unlist(labels)
  }

  if (length(data) != length(labels)) stop(sprintf("1:1 Relation required: %d items vs %d labels.", length(data), length(labels)))
  if (!is.character(labels)) stop(paste("The provided 'labels' must be character strings.\n Found class:", class(labels)))

  if (anyDuplicated(labels)) {
    duplicated_labels <- unique(labels[duplicated(labels)])
    stop("Please provide unique 'labels' to identify the each piece of data.\n", "Duplicated labels: ", paste(duplicated_labels, collapse = ","))
  }

  return(labels)
}

IsIn_tTEscanR_Object <- function(object, slot = c("assays", "meta.data"), section, subset = NULL, compute_assay = FALSE, update_assay = FALSE, overwrite = FALSE, verbose = TRUE){

  ###
  # CALL: Multiple
  # DESCRIPTION: This function has 2 modes:
  # (i) compute mode - check if all the inputs required are available,
  # (ii) update mode - check if the data will need to be overwritten.
  ###

  slot_name <- match.arg(slot) # Validate the slots
  target_list <- slot(object, slot_name) # Extracts the sections inside the slots
  section_exists <- section %in% names(target_list) # Validate the sections inside the slot

  # Handle the case where the section does NOT exist
  if (!section_exists){
    if (update_assay){
      if (verbose) message(paste("- The", section, "section will be defined."))
      return(invisible(TRUE))
    }

    if (compute_assay){
      if (verbose) message(paste("- Section", section, "is missing."))
      return(FALSE)
    }

    stop("Section '", section, "' not found in slot '", slot_name, "'.")
  }

  # Handle the case where the section DOES exist
  if (verbose) message(paste0("- Section '", section, "' exists in '", slot_name, "'."))
  if (update_assay){
    already_exists <- FALSE

    if (!is.null(subset)){
      if (subset %in% names(target_list[[section]])) already_exists <- TRUE
    } else {
      already_exists <- TRUE
    }

    if (already_exists) {
      if (!overwrite) stop("Section '", section, "' exists. Set 'overwrite = TRUE' to replace it.")
    }

    if (verbose){
      if (!is.null(subset)){
        message(paste0("- Subset '", subset, "' in section '", section, "' will be overwritten."))
      } else {
        message(paste0("- Section '", section, "' will be overwritten."))
      }
    }
  }

  if (compute_assay) return(TRUE)

  return(invisible(TRUE))
}
