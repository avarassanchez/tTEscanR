#' @importFrom stats pnorm sd
utils::globalVariables(c("AA", "sums"))
NULL

#' Compute (theoretical) Translation Efficiency
#'
#' @param object A \code{tTEscanR_Object} containing a mRNA and a codon usage assay.
#' @param conditions A vector with the labels for each section of the conditions labels.
#' @param name_sep Specification of the notation separation used in the condition labels to run a DESeq2 analysis.
#' @param formula Design formula to use for the DESeq2 analysis. The name of the factors needs to be consistent with the column names of the \code{conditions}.
#' @param verbose A boolean parameter to specify if the messages within the function should be display.
#'
#' @return An updated \code{tTEscanR_Object} containing a new layer of information representing the translation efficiency table for the matching conditions in mRNA and tRNA data.
#' @export
#'
#' @examples
#' data(mRNA_data)
#' data(tRNA_data)
#' mRNA_data_translated <- TranslateGeneName(data_to_translate = mRNA_data,
#'                                           species = "hg38",
#'                                           position = "row",
#'                                           notation = "id")
#' tTEobj <- Create_tTEscanR_Object(counts = list(mRNA_data_translated, tRNA_data),
#'                                  assay = list("mRNA", "tRNA"))
#' tTEobj <- ComputeCodonUsage(object = tTEobj,
#'                             codon_freq = NULL,
#'                             species = "hg38",
#'                             filter = "canonical",
#'                             reduce = 10000)
#' tTEobj <- ComputeAnticodonUsage(object = tTEobj)
#' tTEobj <- ComputeAAUsage(object = tTEobj, action = "both")
#' tTEobj <- Compute_tTE(object = tTEobj,
#'                       conditions = c("tissue", "cell.type"),
#'                       name_sep = "-",
#'                       formula = ~ tissue)

Compute_tTE <- function(object,
                        level,
                        conditions,
                        name_sep,
                        formula,
                        verbose = TRUE){

  if (verbose) message("1. Evaluating the input tTEscanR object.")
  if (!inherits(object, 'tTEscanR_Object')){
    stop("`object` must be a tTEscanR object.")
  }

  if (level == "AA"){
    IsIn_tTEscanR_Object(object = object, section = "AADemand", update.assay = FALSE, overwrite = FALSE, verbose = verbose)
    IsIn_tTEscanR_Object(object = object, section = "AASupply", update.assay = FALSE, overwrite = FALSE, verbose = verbose)
    data_from_mRNA <- object@assays$AADemand
    data_from_tRNA <- object@assays$AASupply
  } else if (levle == "codon"){
    IsIn_tTEscanR_Object(object = object, section = "CodonUsage", update.assay = FALSE, overwrite = FALSE, verbose = verbose)
    IsIn_tTEscanR_Object(object = object, section = "AnticodonUsuage", update.assay = FALSE, overwrite = FALSE, verbose = verbose)
    data_from_mRNA <- object@assays$CodonUsage
    data_from_tRNA <- object@assays$AnticodonUsage
  } else {
    stop("- Please specify a valid `level` input parameter: codon or AA.")
  }

  IsIn_tTEscanR_Object(object = object, section = "tRNA", update.assay = FALSE, overwrite = FALSE, verbose = verbose)
  ExistMetadata_tTEscanR_Object(object = object, section = "tRNAsAnticodons", update.metadata = FALSE, overwrite = FALSE, verbose = verbose)

  if (verbose) {
    message("2. Size correcting the input matrices.")
    message("- AA demand matrix.\n")
  }
  data_from_mRNA <- ComputeSizeCorrection(data = data_from_mRNA, runDESeq2 = TRUE, name_sep = name_sep, conditions = conditions, formula = formula, verbose = verbose)
  if (verbose && level == "AA") message("- AA supply matrix.\n")
  if (verbose && level == "codon") message("- Codon usage matrix.\n")
  data_from_tRNA <- ComputeSizeCorrection(data = data_from_tRNA, runDESeq2 = TRUE, name_sep = name_sep, conditions = conditions, formula = formula, verbose = verbose)
  if (verbose && level == "AA") message("- tRNA gene expression matrix.\n")
  if (verbose && level == "codon") message("- Anticodon usage expression matrix.\n")
  tRNA_exp_data <- ComputeSizeCorrection(data = object@assays$tRNA, runDESeq2 = TRUE, name_sep = name_sep, conditions = conditions, formula = formula, verbose = verbose)

  if (verbose) message("3. Extacting matching conditions in the mRNA and tRNA datasets.")
  tTE_conditions <- intersect(colnames(data_from_mRNA), colnames(data_from_tRNA))

  if (length(tTE_conditions) == 0){
    stop("No intersecting condition were found between the matrices.\n",
         "If needed check that the annotation between the matrices follows the same format.\n",
         "Check the correct use of the `name_sep` input parameter.")
  } else {
    if (verbose) message(paste("- A total of ", length(tTE_conditions), "intersecting conditions were found."))
  }

  if (verbose) message("4. Filtering the size corrected datasets by the intersecting conditions.")
  filtered_tRNA_data <- data_from_mRNA[amino_acids, tTE_conditions]
  filtered_mRNA_data <- data_from_tRNA[amino_acids, tTE_conditions]

  TEs_at_AA_level <- numeric(length(tTE_conditions))
  names(TEs_at_AA_level) <- tTE_conditions

  if (verbose) message("5. Computing Spearman correlation.")
  for (i in 1:length(tTE_conditions)) {
    select_condition <- tTE_conditions[i]
    AA_supply_from_tRNA <- filtered_tRNA_data[, select_condition]
    AA_demand_from_mRNA <- filtered_mRNA_data[amino_acids, select_condition]

    # The tTE is computed as the Spearman's rank correlation coefficient
    TEs_at_AA_level[i] <- cor(AA_supply_from_tRNA, AA_demand_from_mRNA, method = "spearman")
  }

  if (verbose) message("6. Determining statistical significance of translation efficiencies.")
  AAs_for_tRNA_genes <- as.vector(Biostrings::translate(Biostrings::reverseComplement(Biostrings::DNAStringSet(object@meta.data$tRNAsAnticodons)),
                                                        no.init.codon = TRUE))
  TE_p_values <- numeric(length(tTE_conditions))

  for (i in 1:length(tTE_conditions)) {
    select_ATAC_condition <- tTE_conditions[i]
    select_RNA_condition <- tTE_conditions[i]

    N = 1000 # number of null distribution samplings
    mRNA_AA_usage <- aa_demand[amino_acids, select_RNA_condition] # observed (true) AA supply usage for this condition
    true_tRNA_usage <- tRNA_exp_data[, select_ATAC_condition] # observed (true) tRNA gene usage for this condition: this will be shuffled N times to determine statistical significance

    null_TEs_AA = numeric(N)
    for (j in 1:N) {
      shuffled_tRNA_usage <- sample(true_tRNA_usage)  # sum up the cuts for each tRNA gene across all examples of that condition, shuffle it using sample()

      random_tibble <- tibble::tibble(
        sums = shuffled_tRNA_usage,
        AA = AAs_for_tRNA_genes
      )

      random_tRNA_AA_usage <- dplyr::summarize(group_by(random_tibble, .data$AA), sums = sum(.data$sums))
      random_tRNA_AA_usage <- random_tRNA_AA_usage[which(random_tRNA_AA_usage$AA %in% amino_acids), ]
      random_tRNA_AA_usage <- random_tRNA_AA_usage$sums

      # calculate TE (correlated between shuffled AA supply and unshuffled AA demand)
      random_tRNA_AA_usage <- random_tRNA_AA_usage / sum(random_tRNA_AA_usage)
      null_TEs_AA[j] <- cor(random_tRNA_AA_usage, mRNA_AA_usage, method = 'spearman')
    }

    # fit parameters (mu and sigma for null distribution)
    null_TEs_AA <- data.frame(null_dist = null_TEs_AA)
    mean_random_correlations <- mean(null_TEs_AA$null_dist)
    sd_random_correlations <- sd(null_TEs_AA$null_dist)

    TE_p_values[i] <- 1 - pnorm(TEs_at_AA_level[i], mean = mean_random_correlations, sd = sd_random_correlations) # Calculate p-value for the actual TE
  }

  if (verbose) message("7. Updating the tTEscanR object.")
  TE_results_tibble <- tibble::tibble(
    condition <- names(TEs_at_AA_level),
    TE <- TEs_at_AA_level,
    p_value <- TE_p_values,
    neg_log10_TE_p_value <- -log10(TE_p_values)
  )

  object <- Update_tTEscanR_Object(object = object,
                                   counts = NULL,
                                   assay = NULL,
                                   meta.data = list(TE_results_tibble),
                                   meta.data.ids = list("tTEresults"),
                                   verbose = verbose)

  return(object)
}
