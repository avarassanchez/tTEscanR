## ----file_settings, include = FALSE-------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----notes_format, echo = FALSE, results = 'asis'-----------------------------
cat("
<style>
.note {
    background-color: #f6e8c3;
    border-left: 5px solid #dfc27d;
    padding: 1em;
    margin: 1em 0;
    border-radius: 4px;
}
.warning {
    background-color: #fff3cd;
    border-left: 5px solid #ff9800;
    padding: 1em;
    margin: 1em 0;
    border-radius: 4px;
}
</style>
")

## ----setup, message = FALSE, warning = FALSE----------------------------------
# install.packages("/avarassanchez/tTEscanR")
devtools::load_all()
library(tTEscanR)

## ----load_datasets, message = FALSE, warning = FALSE--------------------------
data(
    default_tTEscanR_mRNA_data,
    default_tTEscanR_tRNA_data,
    default_tTEscanR_metadata
)

## ----execute_workflow, message = FALSE, warning = FALSE-----------------------
tTEobject <- RunPipeline(
    mRNA_data = default_tTEscanR_mRNA_data,
    tRNA_data = default_tTEscanR_tRNA_data,
    metadata = default_tTEscanR_metadata,
    species = "hg38", batch = "tissue",
    runDESeq = FALSE, verbose = FALSE
)

## ----check_codon_usage, eval = FALSE------------------------------------------
# head(getAssay(tTEobject, "CodonUsage"))

## ----codon_usage_data_transform-----------------------------------------------
long_format_codon_usage <- TransformFormat(
    data = getAssay(tTEobject, "CodonUsage"), normalize = TRUE,
    rownames_to_column = "codon", # features (row) of the CodonUsage matrix
    names_to = "condition", # conditions (col) of the CodonUsage matrix
    values_to = "usage"
) # values of the CodonUsage matrix

# long_format_codon_usage contains 3 columns: codon, condition, usage
# We are going to divide the condition column into tissue and cell_type
long_format_codon_usage <- long_format_codon_usage %>%
    tidyr::separate(.data$condition, into = c("tissue", "cell_type"), sep = "-")

## ----check_long_codon_usage, eval = FALSE-------------------------------------
# head(long_format_codon_usage)

## ----aa_demand_data_transform-------------------------------------------------
long_format_AA_demand <- TransformFormat(
    data = getAssay(tTEobject, "AADemand"), normalize = TRUE,
    rownames_to_column = "AA", # features (row) of the AADemand matrix
    names_to = "condition", # conditions (col) of the AADemand matrix
    values_to = "demand"
) # values of the AADemand matrix

# long_format_AA_demand contains 3 columns: AA, condition, demand
# We are going to divide the condition column into tissue and cell_type
long_format_AA_demand <- long_format_AA_demand %>%
    tidyr::separate(.data$condition, into = c("tissue", "cell_type"), sep = "-")

## ----general_dist_plot, fig.width =  7, fig.height = 4, fig.align = 'center'----
# Codon usage distribution plot (jitter)
PlotDistribution(
    data = long_format_codon_usage, plot = "jitter", x_axis_col = "codon",
    y_axis_col = "usage", condition_col = "tissue", show_legend = "right",
    add_titles = FALSE
)

## ----generate_subset_data-----------------------------------------------------
# Data subset: spleen tissue and selected cell types (lymphoid and myeloid)
spleen_indexes <- grep("Spleen", long_format_codon_usage$tissue)
long_format_cu_spleen <- long_format_codon_usage[spleen_indexes, ]

lymphoid_indexes <- grep("Lymphoid", long_format_cu_spleen$cell_type)
myeloid_indexes <- grep("Myeloid", long_format_cu_spleen$cell_type)

cells_indexes <- c(lymphoid_indexes, myeloid_indexes)

long_format_codon_usage_subset <- long_format_cu_spleen[cells_indexes, ]

## ----dist_barplot, fig.width =  7, fig.height = 4, fig.align = 'center'-------
# Codon usage distribution plot (barplot)
PlotDistribution(
    data = long_format_codon_usage_subset, plot = "barplot", ncols = 1,
    facet_col = "cell_type",
    x_axis_col = "codon", y_axis_col = "usage", condition_col = "cell_type",
    show_legend = "none", add_titles = FALSE
)

## ----generate_subset_data_2---------------------------------------------------
# Data subset: specific codons in spleen and heart tissues
spleen_indexes <- grep("Spleen", long_format_codon_usage$tissue)
heart_indexes <- grep("Heart", long_format_codon_usage$tissue)

tissue_indexes <- c(spleen_indexes, heart_indexes)

long_format_cu_tissues <- long_format_codon_usage[tissue_indexes, ]

selected_codons <- c(
    "CAA", "CAC", "CAG", "CAT", "CCA", "CCC", "CCG", "CCT", "CGA", "CGC",
    "CGG", "CGT", "CTA", "CTC", "CTG", "CTT", "GAA", "GAC", "GAG", "GAT",
    "GCA", "GCC", "GCG", "GCT", "GGA", "GGC", "GGG", "GGT", "GTA", "GTC",
    "GTG", "GTT"
)

codons_indexes <- which(long_format_cu_tissues$codon %in% selected_codons)
long_format_cu_tissues <- long_format_cu_tissues[codons_indexes, ]

## ----distribution_plot, fig.width =  6, fig.height = 4, fig.align = 'center'----
# Codon usage distribution plot (barplot)
PlotDistribution(
    data = long_format_cu_tissues, plot = "boxplot",
    x_axis_col = "codon", y_axis_col = "usage", add_stats = FALSE,
    condition_col = "tissue",
    color_palette = c(Heart = "#de77ae", Spleen = "#7fbc41"),
    show_legend = "bottom", add_titles = FALSE
)

## ----cerebellum_mean----------------------------------------------------------
# Data subset: mean codon usage across cerebellum cell types
codon_usage <- getAssay(tTEobject, "CodonUsage")
cerebellum_indexes <- grep("Cerebellum", colnames(codon_usage))
cerebrum_indexes <- grep("Cerebrum", colnames(codon_usage))
brain_indexes <- c(cerebellum_indexes, cerebrum_indexes)
brain_codon_usage <- codon_usage[, brain_indexes]

# Define the metadata
metadata_brain <- data.frame(
    label = colnames(brain_codon_usage), stringsAsFactors = FALSE
)
metadata_brain <- tidyr::separate(
    metadata_brain, label,
    into = c("tissue", "cell.type"), sep = "-"
)
metadata_brain$conditions <- colnames(brain_codon_usage)

mean_brain_codon_usage <- ComputeMeanUsage(
    data = brain_codon_usage, metadata = metadata_brain,
    batch = "tissue", verbose = FALSE
)

## ----compare_to_mean_plot, fig.width = 7, fig.height = 4, fig.align = 'center'----
additional_metrics <- getMetadata(tTEobject, "CodonUsage_AdditionalMetrics")
PlotTargetComparison(
    target_data = data.frame(mean_brain_codon_usage),
    overall_data = data.frame(additional_metrics$MeanCodonUsage),
    x_axis_col = "feature", y_axis_col = "mean_usage_across_conditions",
    show_difference = TRUE, add_titles = FALSE
)

## ----extract_mean-------------------------------------------------------------
mean_codon_usage <- additional_metrics$MeanCodonUsage
mean_codon_usage$codon <- mean_codon_usage$feature

mean_codon_usage <- FeaturesToAA(
    data = mean_codon_usage, position = "feature",
    notation_from = "codon", notation_to = "aa", verbose = FALSE
)

## ----prop_plot_mean, fig.width = 7, fig.height = 5, fig.align = 'center'------
PlotProportion(
    data = mean_codon_usage, plot = "bar",
    var_numerical = "mean_usage_across_conditions",
    var_categorical = "codon", var_color = "feature", show_legend = "none"
) # Here feature corresponds to AA

## ----mean_AA_demand-----------------------------------------------------------
# Data subset: mean codon usage across cerebellum cell types
aa_demand <- getAssay(tTEobject, "AADemand")
cerebellum_indexes_AA <- grep("Cerebellum", colnames(aa_demand))
cerebrum_indexes_AA <- grep("Cerebrum", colnames(aa_demand))
brain_indexes_AA <- c(cerebellum_indexes_AA, cerebrum_indexes_AA)
brain_AAdemand <- aa_demand[, brain_indexes_AA]

mean_brain_AAdemand <- ComputeMeanUsage(
    data = brain_AAdemand, metadata = metadata_brain,
    batch = "tissue", verbose = FALSE
)

## ----prop_plot_brain, fig.width = 6, fig.height = 4, fig.align = 'center'-----
PlotProportion(
    data = mean_brain_AAdemand, plot = "donut",
    var_numerical = "mean_usage_across_conditions",
    var_categorical = "feature", show_legend = "none"
) # Here feature corresponds to AA

## ----extract_metadata---------------------------------------------------------
conditions_metadata <- getMetadata(tTEobject, "ConditionsLabels")
tTEresults_codon <- getMetadata(tTEobject, "tTEresults_codon")
tTEresults_AA <- getMetadata(tTEobject, "tTEresults_AA")

## ----tTE_scores_plot----------------------------------------------------------
PlotTEscore(
    data = tTEresults_codon, metadata = conditions_metadata,
    index_col = "conditions", class_col = "tissue", add_stats = FALSE
)

## ----target_immune------------------------------------------------------------
# Targeted condition: lymphoid and myeloid cells
conditions_metadata$group <- "other"
conditions_metadata$group[
    grep("Myeloid", conditions_metadata$conditions)
] <- "myeloid"
conditions_metadata$group[
    grep("Lymphoid", conditions_metadata$conditions)
] <- "lymphoid"

## ----score_plot_immune, fig.width = 6, fig.height = 4, fig.align = 'center'----
# input data has 4 columns: condition, tTE, p_value, neg_log10_tTE_p_value
# Codon-anticodon tTE score
PlotTEscore(
    data = tTEresults_codon, metadata = conditions_metadata,
    index_col = "conditions", class_col = "group",
    color_palette = c(
        myeloid = "#abd9e9", lymphoid = "#f1b6da", other = "#fee0b6"
    ),
    add_stats = TRUE
)

# AA demand-supply tTE score
PlotTEscore(
    data = tTEresults_AA, metadata = conditions_metadata,
    index_col = "conditions", class_col = "group",
    color_palette = c(
        myeloid = "#abd9e9", lymphoid = "#f1b6da", other = "#fee0b6"
    ),
    add_stats = FALSE
)

## ----target_neurons-----------------------------------------------------------
# Targeted condition: neurons
conditions_metadata$group <- "other"
conditions_metadata$group[grep(
    "neuron", conditions_metadata$conditions
)] <- "neurons"
conditions_metadata$group[grep(
    "ENS neuron", conditions_metadata$conditions
)] <- "other"

## ----score_plot_neurons, fig.width = 6, fig.height = 4, fig.align = 'center'----
# AA demand-supply tTE score
PlotTEscore(
    data = tTEresults_AA, metadata = conditions_metadata,
    index_col = "conditions", class_col = "group",
    color_palette = c(neurons = "#8073ac", other = "#fee0b6"),
    add_stats = TRUE
)

## ----session-info, echo=FALSE-------------------------------------------------
sessionInfo()

