## ----file_settings, include = FALSE-------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----notes_format, echo = FALSE, results = 'asis'-----------------------------
cat("
<style>
.note {
    background-color: #f6e8c3;
    border-left: 5px solid #dfc27d;
    padding: 1em;
    margin: 1em 0;
    border-radius: 4px;
}
.warning {
    background-color: #fff3cd;
    border-left: 5px solid #ff9800;
    padding: 1em;
    margin: 1em 0;
    border-radius: 4px;
}
</style>
")

## ----setup, message = FALSE, warning = FALSE----------------------------------
# install.packages("/avarassanchez/tTEscanR")
devtools::load_all()
library(tTEscanR)

## ----load_data_mRNA, message = FALSE, warning = FALSE-------------------------
data(default_tTEscanR_mRNA_data)

## ----load_data_tRNA, message = FALSE, warning = FALSE-------------------------
data(default_tTEscanR_tRNA_data)

## ----filter_tRNAs, message = FALSE, warning = FALSE---------------------------
filtered_tRNA_data <- tRNAFilterCuts(
    data = default_tTEscanR_tRNA_data, cutoff = 5000
)

## ----metadata_definition, message = FALSE, warning = FALSE--------------------
data(default_tTEscanR_metadata)

## ----CreateObject, message = FALSE, warning = FALSE---------------------------
# Adding the mRNA and tRNA datasest to the object
tTEobject <- CreateObject(
    counts = list(default_tTEscanR_mRNA_data, filtered_tRNA_data),
    assay = list("mRNA", "tRNA"),
    meta.data = default_tTEscanR_metadata, meta.data.ids = "ConditionsLabels"
)

## ----UpdateObject, message = FALSE, warning = FALSE---------------------------
# Updating the object created before some metadata for reference
matching_celltypes <- intersect(
    colnames(default_tTEscanR_mRNA_data), colnames(filtered_tRNA_data)
)

tTEobject <- UpdateObject(
    object = tTEobject, meta.data = matching_celltypes,
    meta.data.ids = "matching_celltypes", overwrite = TRUE
)

## ----codon_usage, message = FALSE, warning = FALSE----------------------------
# We first need to add the correction factor to the tTEscanR object
# It has to be stored as CorrectionFactor
tTEobject <- UpdateObject(
    object = tTEobject, meta.data = "tissue", meta.data.ids = "CorrectionFactor"
)

tTEobject <- ComputeCodonUsage(
    object = tTEobject, codon_freq = NULL, species = "hg38",
    additional_metrics = TRUE, overwrite = TRUE
)

## ----correlation_plot_mean, message = FALSE, warning = FALSE------------------
# Transforming the data
additional_metrics <- getMetadata(tTEobject, "CodonUsage_AdditionalMetrics")
mean_codon_usage <- additional_metrics$MeanCodonUsage
exonic_background <- additional_metrics$CodonExonicBackground
exonic_background <- as.data.frame(exonic_background)
correlation_mean_background <- cbind(mean_codon_usage, exonic_background)

PlotCorrelation(
    data = correlation_mean_background, plot = "MeanCodonUsage",
    x_axis_col = "mean_usage_across_conditions",
    y_axis_col = "exonic_background",
    extra_val = additional_metrics$MeanCodonCorr,
    condition_col = "feature", # Here feature = codons
    add_titles = TRUE, show_legend = "none"
)

## ----codon_pool_contribution, message = FALSE, warning = FALSE----------------
tTEobject <- ShowPoolContribution(
    object = tTEobject, N = 10, species = "hg38", overwrite = TRUE
)

## ----correlation_plot_diversity, message = FALSE, warning = FALSE-------------
# Transforming the data
codon_pool_contr <- getMetadata(tTEobject, "CodonPoolContribution_Results")
codon_pool_diversity <- codon_pool_contr$top10GenesCodonPoolDiversity
colnames(codon_pool_diversity) <- c(
    "condition", "original_top_contribution", "baseline_correlation"
)
codon_pool_diversity <- codon_pool_diversity %>%
    tidyr::separate(
        .data$condition,
        into = c("tissue", "cell_type"), sep = "-"
    )

PlotCorrelation(
    data = codon_pool_diversity, plot = "PoolDiversity",
    x_axis_col = "original_top_contribution",
    y_axis_col = "baseline_correlation",
    condition_col = "tissue", label_col = "cell_type", show_legend = "right"
)

## ----anticodon_usage, message = FALSE, warning = FALSE------------------------
tTEobject <- ComputeAnticodonUsage(object = tTEobject)

## ----ammino_acid_demand, message = FALSE, warning = FALSE, eval = FALSE-------
# # Computing AA demand
# tTEobject <- ComputeAAUsage(object = tTEobject, level = "demand")

## ----ammino_acid_supply, message = FALSE, warning = FALSE, eval = FALSE-------
# # Computing AA supply
# tTEobject <- ComputeAAUsage(object = tTEobject, level = "supply")

## ----ammino_acid, message = FALSE, warning = FALSE----------------------------
# Computing simultaneously AA demand and supply
tTEobject <- ComputeAAUsage(
    object = tTEobject, level = "both",
    overwrite = TRUE
)

## ----tTE_score_codon, message = FALSE, warning = FALSE,eval = FALSE-----------
# # Computing tTE at the codon-anticodon level
# tTEobject <- Compute_tTE(object = tTEobject, level = "codon")

## ----tTE_score_aa, message = FALSE, warning = FALSE, eval = FALSE-------------
# # Computing tTE at the AA demand-supply level
# tTEobject <- Compute_tTE(object = tTEobject, level = "aa")

## ----tTE_score, message = FALSE, warning = FALSE------------------------------
# Computing simultaneously tTE at codon-anticodon and AA demand-supply levels
tTEobject <- Compute_tTE(object = tTEobject, level = "both", overwrite = TRUE)

## ----extract_metadata---------------------------------------------------------
conditions_metadata <- getMetadata(tTEobject, "ConditionsLabels")

## ----tTE_score_plots, fig.width =  6, fig.height = 4, fig.align = 'center'----
tTEresults_codon <- getMetadata(tTEobject, "tTEresults_codon")
tTEresults_AA <- getMetadata(tTEobject, "tTEresults_AA")

PlotTEscore(
    data = tTEresults_codon, metadata = conditions_metadata,
    index_col = "conditions", class_col = "tissue", add_stats = FALSE
)

PlotTEscore(
    data = tTEresults_AA, metadata = conditions_metadata,
    index_col = "conditions", class_col = "tissue", add_stats = FALSE
)

## ----targeted_metadata_neurons------------------------------------------------
conditions_metadata$group <- "other"
conditions_metadata$group[grep(
    "neuron", conditions_metadata$conditions
)] <- "neurons"
conditions_metadata$group[grep(
    "ENS neuron", conditions_metadata$conditions
)] <- "other"

## ----tTE_plot_neurons, fig.width =  6, fig.height = 4, fig.align = 'center'----
# Use tTEresults_codon to assess the codon-anticodon level
PlotTEscore(
    data = tTEresults_AA, metadata = conditions_metadata,
    index_col = "conditions", class_col = "group", add_stats = TRUE
)

## ----assays_list--------------------------------------------------------------
# Other outputs that could be analyzed:
# mRNA <- getAssay(tTEobject, "mRNA")
# CodonUsage <- getAssay(tTEobject, "CodonUsage")
# tRNA <- getAssay(tTEobject, "tRNA")
# AnticodonUsage <- getAssay(tTEobject, "AnticodonUsage")

AA_results <- list(
    AADemand = getAssay(tTEobject, "AADemand"),
    AASupply = getAssay(tTEobject, "AASupply")
)

## ----run_dea, message = FALSE, warning = FALSE, eval = FALSE------------------
# all_DESeq2_results <- RunDEAnalysis(
#     list_data = AA_results, metadata = metadata, heatmap = TRUE,
#     dim_reduct = "PCA", numPC = 2, batch = "tissue",
#     color_factor = "tissue", show_legend = "right", label_factor = "cell.type"
# )
# 
# grid.draw(all_DESeq2_results$plots$AADemand$heatmap) # Visualize heatmap plot
# all_DESeq2_results$plots$AADemand$exploratory$ElbowPlot # Visualize elbow plot
# all_DESeq2_results$plots$AADemand$exploratory$PC1_vs_PC2 # Visualize PCA plot

## ----session-info, echo=FALSE-------------------------------------------------
sessionInfo()

